<?php
    require_once("application/config/config.php");
    require_once("application/library/database.php");
    require_once("system/model.php");
    require_once("system/loadcontroller.php");
    require_once("system/controller.php");
    require_once("system/loadview.php");
    require_once("system/loadmodel.php");
    $obj = new loadcontroller;