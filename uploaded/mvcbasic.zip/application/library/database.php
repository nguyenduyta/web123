<?php
/**
 * Xử lý các thao tác với database;
 */
class database
{
    protected $_connect;
    protected $_result;
    /**
     * Kết nối database;
     */
    public function connect()
    {
        $this->_connect = mysql_connect(config::hostname,config::username,config::password) or die("Disconnect data base");
        if(!$this->_connect){
            die("Select database can not !");
        }else{
            mysql_select_db(config::dbname,$this->_connect);
        }
        mysql_query("set names 'utf8'",$this->_connect);
        
    }
    /**
     * Thực hiện câu truy vấn 
     */
    public function query($sql = "")
    {
        if(!$this->_connect) {
            die("Can not query mysql");    
        }
        $this->_result = mysql_query($sql);
    }
    
    /**
     * Lay tong so ban ghi
     */
    public function numRow(){
        if(!$this->_result){
            die("Can not get numrow !");
        }
        return mysql_num_rows($this->_result);
    }
    /**
     *  Lay ra mot ban ghi trong table 
     */
    public function fetch()
    {
        if(!$this->_result){
            die("Can not fetch data !");
        }
        return mysql_fetch_assoc($this->_result);
    }
    
    /**
     *  Lay ra mot ban ghi trong table 
     */
    public function fetchAll()
    {
        $data = array();
        if(!$this->_result){
            die("Can not fetchAll data !");
        }
        while($row = mysql_fetch_assoc($this->_result)) {
            $data[] = $row;
        }
        return $data;
    }
}