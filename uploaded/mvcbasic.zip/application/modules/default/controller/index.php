<?php
class index
{
    public function index()
    {
        echo __METHOD__;
    }
}