<?php
class usermodel extends model
{
    protected $_table = "tbl_user";
    protected $_id    = "id";
    public function listUser()
    {
       return $this->getAll($this->_table);
    }
    public function insertUser($data)
    {
        $this->insert($this->_table,$data);
    }
}