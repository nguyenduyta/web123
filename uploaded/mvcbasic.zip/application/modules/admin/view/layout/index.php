<?php
    require_once("top.php");
    if(isset($template) && $template != null ){
        require_once("application/modules/admin/view/".$template.".php");   
    }
    require_once("left.php");     
