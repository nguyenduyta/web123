<?php
class index 
{
    public function index()
    {
        echo "<h1>".__METHOD__."</h1>";
    }
}