<?php
class user extends controller
{
    public function index()
    {
        $data['template'] = "user/default";
        $this->loadview("layout/index",$data);
    }
    public function insert()
    {
        $data['template'] = "user/insert";
        $this->loadview("layout/index",$data);
    }
} 
