<?php
class loadcontroller
{
    public function __construct()
    {
        $params = $_REQUEST;
        $module = isset($params['module']) && $params['module'] != null ? $params['module'] : "default";
        $controller = isset($params['controller']) && $params['controller'] != null ? $params['controller'] : "index";
        $action = isset($params['action']) && $params['action'] != null ? $params['action'] : "index";
        require("application/modules/{$module}/controller/{$controller}.php");
        
        $obj = new $controller;
        $obj->$action();
    }
}