<?php
class loadmodel
{   
    public function __construct($nameModel = "") 
    {
        $params = $_REQUEST;
        $module = isset($params['module']) && $params['module'] != null ? $params['module'] : "default";
        $urlRequire = "application/modules/{$module}/model/{$nameModel}.php";
        require_once($urlRequire);
    }
}