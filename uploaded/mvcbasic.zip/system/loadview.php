<?php
class loadview
{
    public function __construct($url,$data=array()) 
    {
        foreach($data as $key=>$val){
            if(isset($key) && $key != null) {
                $$key = $val;
            }
        }
        $params = $_REQUEST;
        $module = isset($params['module']) && $params['module'] != null ? $params['module'] : "default";
        $urlRequire = "application/modules/{$module}/view/{$url}.php";
        require_once($urlRequire);
    }
}