<?php
class  controller
{
    protected $view;
    protected $model;
    public function loadview($url,$data = array())
    {
        $this->view = new loadview($url,$data);
    }
    public function loadmodel($nameModel  = "" ){
        $this->model = new loadmodel($nameModel);
    }
}