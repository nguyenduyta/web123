<?php
class model extends database{
    protected $_select ="*";
    protected $_where;
    protected $_limit;
    protected $_order;
    
    public function __construct() 
    {
        $this->connect();
    }
    public function setWhere($where=""){
        $this->_where = "WHERE $where";
    }
    public function getWhere(){
        return $this->_where;
    }
    public function setOrder($column="",$sort = "ASC"){
        if($column == "") {
            return false;
        }
        if($sort != "ASC"){
            $this->_order = "ORDER BY $column $sort";   
        }
    }
    public function getOrder(){
        return $this->_order;
    }
    
    public function setLimit($limit = "", $start = "") {
        if($start == "" && $limit != ""){
            $this->_limit = "LIMIT $limit";
        }else if($start != "" && $limit != "") {
            $this->_limit = "LIMIT $start,$limit";
        }else{
            return false;
        }
    }
    public function getLimit(){
        return $this->_limit;
    }
    public function setSelect($column = array()){
        if($column != null ){
            $this->_select = implode(",",$column);
        }
    } 
    public function getSelect(){
        return $this->_select;
    }
    /**
     * Lay ra danh sach
     * 
     */
    public function getAll($table = "")
    {
        if($table == "") {
            return false;
        }
        $select = "SELECT "
                .$this->getSelect()." FROM $table "
                .$this->getWhere()." "
                .$this->getOrder()
                .$this->getLimit();
        $this->query($select);
        return $this->fetchAll();
    }
    /**
     * Insert data
     */
    public function insert($table = "",$data=array())
    {
        if($data == null || $table == "" ) {
            return false;
        }
        echo "<pre>";
        foreach($data as $key=>$val){
            $column[] = $key;
            $values[] = "'".$val."'";
        }
        
        $columns = implode(",",$column);
        $value   = implode(",",$values);
        $sql = "INSERT INTO $table($columns) VALUES($value)";
        $this->query($sql);
    }
}