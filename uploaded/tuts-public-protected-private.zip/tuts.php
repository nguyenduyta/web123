<meta charset="utf-8" />
<?php
/**
* web24h.com.vn
*/
class sinhvien
{
	public    $fullname  //Truy cập mọi nơi
	protected $email;   //Truy trong class và class kế thừa
	private   $address //Chỉ truy cập trong class;

	protected function sleep() //Truy cập trong class và class kế thừa
	{
		return "Tôi đang ngủ";
	}

	public function talk() //Chỉ truy cập trong class
	{
		return "Tôi đang nói chuyện";
	}
}

$obj = new sinhvien;
echo $obj->talk();
echo $obj->sleep(); //Xảy ra lỗi


