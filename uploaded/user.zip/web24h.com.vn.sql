-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 27, 2014 at 10:58 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `phpsmartosc`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_new`
--

CREATE TABLE IF NOT EXISTS `tbl_new` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `desc` varchar(500) NOT NULL,
  `full` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_new`
--

INSERT INTO `tbl_new` (`Id`, `title`, `desc`, `full`, `status`) VALUES
(1, 'abc', 'xcxmcb asjdha cashcka cahc', 'ajscjkahsjc ka cacadch akdjc akd chakdjchkajhc jadhc kahdc had jchjkadhc ahc kahjdhckjadhc ahdc ', 1),
(2, '1', '1', '1', 1),
(3, 'zxczx', 'czxcz', 'xczxczxc', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` char(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(15) NOT NULL,
  `level` char(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `password`, `email`, `address`, `phone`, `level`) VALUES
(2, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 'admin@local.com', 'Vinh Phuc', '1234567', '2'),
(4, 'kenny', 'd41d8cd98f00b204e9800998ecf8427e', 'kenny@gmail.com', '', '', '1'),
(8, 'viet', 'd41d8cd98f00b204e9800998ecf8427e', 'funaway89@gmail.com', '', '', '1'),
(9, 'a', 'd41d8cd98f00b204e9800998ecf8427e', 'a', '', '', '2'),
(10, 'abc', 'e10adc3949ba59abbe56e057f20f883e', 'funaway891@gmail.com', 'abc', '123', '1'),
(11, 'abcd', 'e10adc3949ba59abbe56e057f20f883e', 'funaway8912@gmail.com', 'abc', '123', '1'),
(12, 'abcde', 'e10adc3949ba59abbe56e057f20f883e', 'funaway89122@gmail.com', 'abc', '123', '1'),
(13, 'abcdde', 'e10adc3949ba59abbe56e057f20f883e', 'funaway891sd2@gmail.com', 'abc', '123', '1'),
(14, 'abcadde', 'e10adc3949ba59abbe56e057f20f883e', 'funaway891wesd2@gmail.com', 'abc', '123', '1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
