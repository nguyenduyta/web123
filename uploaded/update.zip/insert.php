<?php
    session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Thêm Thành Viên</title>
<style>
	form{
		width:500px;
		margin:0px auto;
	}
    
	label{
		width:120px;
		float:left;
	}
    
	input,select{
		margin-bottom:5px;	
	}
    
    body{
        width: 500px;
        margin: 100px auto;
    }
    a{
        text-decoration: none;
        color: blue;
    }
    font{
        padding-left: 120px;
    }
</style>
</head>
<body>
        <?php
            if(isset($_POST['ok'])) {
               $name = $email = $pass = $level = "";
               if($_POST['username'] == ""){
                    $errorName = "Vui long nhap ten";
               }else{
                    $name = $_POST['username'] ;
               }
               if($_POST['email'] == ""){
                    $errorEmail = "Vui long nhap email";
               }else{
                    $email = $_POST['email'] ;
               }
               if($_POST['level'] == ""){
                    $errorLevel = "Vui chon level";
               }else{
                    $level = $_POST['level'] ;
               }
               if($_POST['password'] != ""){
                    if($_POST['repassword'] != $_POST['password']){
                        $errorPass = "Password khong trung nhau";
                    }else{
                        $pass = $_POST['password'];
                    }
               }else{
                    $errorPass = "Vui long nhap password";
               }
               if($name && $level && $pass && $email){
                    $connect = @mysql_connect("localhost","root","") or die("Disconnect database");
                    mysql_select_db("phpsmartosc",$connect);
                    $query = mysql_query("SELECT * FROM tbl_user where email ='".$email."'");
                    $totalCheck = mysql_num_rows($query);
                    if($totalCheck > 0){
                        echo "<p>Email đã tồn tại trong database</p>";
                    }else{
                        echo $sql = "INSERT INTO tbl_user(name,email,password,level) VALUES('".$name."','".$email."','".md5($pass)."','".$level."')";
                        mysql_query($sql);
                        header("location:index.php");   
                    }
               }
            }
        ?>
        <div>
        <a href="">Chào bạn: <?php echo $_SESSION['user']; ?> </a>&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="logout.php">Đăng xuất</a>
        </div>
        <h3>
            Thêm mới thành viên
        </h3>
        <br />
		<form action="insert.php" method="post" name="" enctype="multipart/form-data">
        	<label>Quyền hạn</label>
            		<select name="level">
                    	<option value="" selected="selected">Chọn quyền hạn</option>
                    	<option value="2">Administrator</option>
                        <option value="1">Member</option>
                    </select>
                    <?php
                        echo isset($errorLevel) && $errorLevel != "" ? $errorLevel: "";
                    ?>
                    <br />
        	<label>Tên thành viên</label><input type="text" name="username" value="" size="25" />
                    <?php
                        echo isset($errorName) && $errorName != "" ? $errorName: "";
                    ?>
            <br />
            <label>Mật khẩu</label><input type="text" name="password" value="" size="25" />
                    <?php
                        echo isset($errorPass) && $errorPass != "" ? $errorPass: "";
                    ?>
            <br />
            <label>Mật khẩu nhập lại</label><input type="text" name="repassword" value="" size="25" /><br />
        	<label>Địa Chỉ Email</label><input type="text" name="email" value="" size="25" />
                <?php
                    echo isset($errorEmail) && $errorEmail != "" ? $errorEmail: "";
                ?>
            <br />                        
            <label>&nbsp;</label>
            <input type="submit" name="ok" value="Thêm" />&nbsp;&nbsp;
            <input type="submit" name="ok" value="Làm lại" />
        </form>
</body>
</html>
