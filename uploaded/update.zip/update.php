<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Thêm Thành Viên</title>
<style>
	form{
		width:500px;
		margin:0px auto;
	}
	label{
		width:120px;
		float:left;
	}
	input,select{
		margin-bottom:5px;	
	}
    body{
        width: 500px;
        margin: 100px auto;
    }
    a{
        text-decoration: none;
        color: blue;
    }
    font{
        padding-left: 120px;
    }
</style>
</head>
<body>
        <?php
            if(isset($_GET['id']) && $_GET['id'] != null){
                $connect = @mysql_connect("localhost","root","") or die("Disconnect database");
                mysql_select_db("phpsmartosc",$connect);
                $sql = "SELECT * FROM tbl_user WHERE id='".$_GET['id']."'";
                $query = mysql_query($sql);
                $infoUser = mysql_fetch_assoc($query);
                
                
                // Xu ly check form update
            if(isset($_POST['ok'])){
                $name = $email = $pass = $level = "";
               if($_POST['username'] == ""){
                    $errorName = "Vui long nhap ten";
               }else{
                    $name = $_POST['username'] ;
               }
               if($_POST['email'] == ""){
                    $errorEmail = "Vui long nhap email";
               }else{
                    $email = $_POST['email'] ;
               }
               if($_POST['level'] == ""){
                    $errorLevel = "Vui chon level";
               }else{
                    $level = $_POST['level'] ;
               }
               if($_POST['password'] == ""){
                    $pass = false;
               }else{
                    if($_POST['repassword'] != $_POST['password']){
                        $errorPass = "Password khong trung nhau";
                    }else{
                        $pass = $_POST['password'];
                    }
               }
               if($name && $level && $email){
                    $sqlCheck = "SELECT * FROM tbl_user where email='".$email."' and id!='".$_GET['id']."'";
                    $queryCheck = mysql_query($sqlCheck);
                    $totalCheck = mysql_num_rows($queryCheck);
                    if($totalCheck > 0){
                        echo "<p>Email đã tồn tại trong database</p>";
                    }else{
                        if($pass == false){
                        $sql = "UPDATE tbl_user SET
                                        name='".$name."',
                                        email='".$email."',
                                        level='".$level."' 
                                        WHERE id='".$_GET['id']."'
                                ";
                    }else{
                        $sql = "UPDATE tbl_user SET
                                        name='".$name."',
                                        email='".$email."',
                                        level='".$level."',
                                        password='".md5($pass)."'
                                        WHERE id='".$_GET['id']."'
                                ";
                    }
                    mysql_query($sql);
                    header("location:index.php");   
                }
               }
            }
        }
        ?>
        <div>
        <a href="">Chào bạn:</a>&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="logout.php">Đăng xuất</a>
        </div>
        <h3>
            Sửa thành viên
        </h3>
		<form action="" method="post" name="" enctype="multipart/form-data">
        	<label>Quyền hạn</label>
            		<select name="level">
                    	<option value="0">Chọn quyền hạn</option>
                        <option value="2" <?php  if($infoUser['level'] == 2){ echo "selected='selected'"; }?>>Administrator</option>
                        <option value="1"  <?php  if($infoUser['level'] == 1){ echo "selected='selected'"; }?>>Member</option>
                    </select>
                        <?php
                            echo isset($errorLevel) && $errorLevel != "" ? $errorLevel: "";
                        ?>
                    <br />
        	<label>Tên thành viên</label><input type="text" name="username" value="<?php echo $infoUser['name']; ?>" size="40" />
                <?php
                        echo isset($errorName) && $errorName != "" ? $errorName: "";
                ?>
            <br />
            <label>Mật khẩu</label><input type="text" name="password" value="" size="40" />
                 <?php
                        echo isset($errorPass) && $errorPass != "" ? $errorPass: "";
                 ?>
            <br />
            <label>Mật khẩu nhập lại</label><input type="text" name="repassword" value="" size="40" /><br />
        	<label>Địa Chỉ Email</label><input type="text" name="email" value="<?php echo $infoUser['email']; ?>" size="40" />
                <?php
                    echo isset($errorEmail) && $errorEmail != "" ? $errorEmail: "";
                ?>
            <br />                        
            <label>&nbsp;</label>
            <input type="submit" name="ok" value="Sửa" />&nbsp;&nbsp;
            <input type="submit" name="ok" value="Làm lại" />
        </form>
</body>
</html>
