<meta charset="utf-8" />
<?php
/**
* web24h.com.vn
*/
class clone_php
{
	
	public $name;

	public function setName($value)
	{
		$this->name = $value;
	}

	public function getName()
	{
		return $this->name;
	}
}

$object1 = new clone_php();
$object1->setName("Phạm Kỳ Khôi");
echo $object1->getName(); // In ra Phạm Kỳ Khôi

echo "<br/>";

$object2 = $object1;
$object2->setName("Phạm Kỳ Khiêm");
echo $object1->getName();

