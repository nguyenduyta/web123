<meta charset="utf-8" />
<?php
/**
* web24h.com.vn
*/
class sinhvien
{
	protected $name  = "Phạm Kỳ Khôi";
	protected $email = "phamkykhoi.info@gmail.com";

	function __construct()
	{
		echo $this->name;
	}

	public function __destruct()
	{
		echo "<br/>".$this->email;
	}
}
$objSinhvien = new sinhvien();
/**Kết quả: Phạm Kỳ Khôi
 *          phamkykhoi.info@gmail.com    
 */

