<?php
/**
 * web24h.com.vn
 */
class person
{
    protected static $_name = '';
     
    public static function setName($name)
    {
        person::$_name = $name;
    }
     
    public static function getName(){
        return person::$_name;
    }
}
 
class sinhvien extends person
{
    public static function setName($name) {
        parent::setName($name);
    }
     
}
 
sinhvien::setName('Pham Ky Khoi');
echo person::getName();

