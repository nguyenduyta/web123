<meta charset="utf-8" />
<?php
/**
 * web24h.com.vn
 */
class xe
{
    protected static $_name = 'Xe SH nhập ngoại';

    function setName($name){
        self::$_name = $name;
    }
     
    function getName(){
        return self::$_name;
    }
}
 
//Tạo đối tượng xe SH
$xe_sh = new xe();
$xe_sh->setName('Xe SH Việt');
echo "<br/>".$xe_sh->getName();

//Tạo đối tượng xe Wave
$xe_wave = new xe();
echo "<br/>".$xe_wave->getName();

