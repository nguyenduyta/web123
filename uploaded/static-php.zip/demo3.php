<?php 
/**
 * web24h.com.vn
 */
class sinhvien
{
	static $name = "Phạm Kỳ Khôi";
	public static    $email   = "phamkykhoi.info@gmail.com";
	protected static $address = "Vĩnh Phúc";
	private static   $phone   = "0912.876.421";

	static function getName()
	{
		return sinhvien::$name;
	} 

	public static function getEmail()
	{
		return sinhvien::$email;
	}

	protected static function getAddress()
	{
		return sinhvien::$email;
	} 
}
echo sinhvien::$name;
echo "<br/>";
echo sinhvien::getEmail();

