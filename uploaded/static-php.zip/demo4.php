<?php 
/**
 * web24h.com.vn
 */
class sinhvien
{
	static $name = "Phạm Kỳ Khôi";
	public static    $email   = "phamkykhoi.info@gmail.com";
	protected static $address = "Vĩnh Phúc";
	private static   $phone   = "0912.876.421";

	static function getName()
	{
		return self::$name;
	} 

	public static function getEmail()
	{
		return self::$email;
	}
}
echo sinhvien::getEmail();

