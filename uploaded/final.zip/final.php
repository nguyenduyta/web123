<?php 
/**
 * web24h.com.vn
 */
class person
{
	final public function getName()
	{
		echo "Học PHP tại web24h.com.vn";
	}
}

class hocsinh extends person
{
	public function getName()
	{
		echo "Học PHP tại suntech.edu.vn";	
	}
}
//Khởi tạo đối tượng
$hocsinh = new hocsinh();
$hocsinh->getName();

