<meta charset="utf-8" />
<?php
/**
 * web24h.com.vn
 */
class sinhvien
{
    public $name = '';

    function __set($key, $value){
        if ($key = 'setName'){
            $this->getName = $value;
        }
    }
     
}
 
$class = new sinhvien();
$class->setName = 'Phạm Kỳ Khôi';
echo $class->getName; 
//Kết quả là Phạm Kỳ Khôi

