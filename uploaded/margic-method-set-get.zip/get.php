<?php
class sinhvien
{
    public $username = 'Phạm Kỳ Khôi';
     
    function __get($key){
        if ($key == 'fullname'){
            return $this->username;
        }
    }
     
}
 
$class = new sinhvien();
echo $class->fullname;

