<?php
class demo
{
    public function __clone()
    {
        echo __METHOD__;
    }
}

$obj = new demo();
$obj2 = clone $obj;