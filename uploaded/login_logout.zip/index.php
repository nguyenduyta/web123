<?php
    session_start();
    if(!isset($_SESSION['user']) || $_SESSION['level'] != 2){
        header("location:login.php");
    }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Danh sách thành viên</title>
<style>
    a{
        text-decoration: none;
        color: blue;
    }
	thead td{
		background:#f1f1f1;
		text-align:center;
		padding:0px; margin:0px;
		border:1px solid #fbfbfb;
	}
	tbody td{
		background:#fbfbfb;	
		border:1px solid;
		border:1px solid #f1f1f1;
	}
    body{
        width: 650px;
        margin: 100px auto;
    }
    .pagination{
        text-align:center;
    }
    .pagination a{
        padding:5px;
    }
	#news {
	float:left;
	}
	#newdetail{
	float:left;
	height:500px;
	width:600px;
	border:1px solid;
	}
</style>
<script type="text/javascript">
    function xacnhan(){
        if(!window.confirm("Bạn có thực sự muốn xóa không ?")){
    		return false;
    	}
    }
</script>
</head>
<body>
	<div>
        <a href="">Chào bạn: <?php echo $_SESSION['user']; ?></a>&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="logout.php">Đăng xuất</a>
    </div>
    
</body>
</html>
