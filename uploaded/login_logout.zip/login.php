<?php
    session_start();
?>
<!DOCTYPE HTML>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="htkhoi" />
    <meta charset="utf-8" />
	<title>Đăng nhập hệ thống</title>
    <style>
        body{
            width:500px;
            margin: 100px auto;
        }
        h1{
            color:blue;
            font-size:14px;
            text-transform: uppercase;
            padding-left: 80px;
        }
        label{
            float:left;
            width:80px;
        }
        p{
            padding-left: 85px;
            color: red;
        }
        input{
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <h1>Truy Cập Trang Quản trị</h1>
    <?php
            $email = $password = "";
            if(isset($_POST['ok'])){
                if(!isset($_POST['username']) || $_POST['username'] == NULL){
                    echo "<p>Vui lòng nhập họ tên đầy đủ<p>";
                }else{
                    $email = $_POST['username'];
                }
                if(!isset($_POST['password']) || $_POST['password'] == NULL){
                    echo "<p>Mật khẩu không được bỏ trống<p>";
                }else{
                    $password = $_POST['password'];
                }
                if($email && $password){
                    //Connect database;
                    $connect = @mysql_connect("localhost","root","") or die("Disconnect database");
                    mysql_select_db("phpsmartosc",$connect);
                    $sql = "SELECT * FROM tbl_user WHERE email='".$email."' and password='".md5($password)."'";
                    $query = mysql_query($sql);
                    $total = mysql_num_rows($query);
                    if($total != 0){
                        $userInfo = mysql_fetch_assoc($query);
                        $_SESSION['user'] = $userInfo['name'];
                        $_SESSION['level'] = $userInfo['level'];
                        header("location:index.php");
                    }else{
                        echo "<p>Email or password không đúng !!!</p>";  
                    }
                }
                          
            }
?>
    <form action="login.php" method="post">
        <label>Email</label><input type="text" name="username" size="25" value="" /><br />
        <label>Password</label><input type="text" name="password" size="25" value="" /><br />
        <label>&nbsp;</label>
        <input type="submit" name="ok" value="Đăng nhập" />
    </form>
</body>
</html>