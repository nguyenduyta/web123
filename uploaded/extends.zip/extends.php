<?php 
/**
* web24h.com.vn
*/
class a
{
   public function getName()
   {
   		return "Nguyen Van A";
   }

   private function getEmail()
   {
   		return "aaa@gmail.com";
   }
}

class b extends a {
   //Nothing
}

//Khởi tạo đối tượng từ class b
$obj = new b;
echo "<br/>".$obj->getName();
echo "<br/>".$obj->getEmail(); //Xảy ra lỗi do mang cơ chế private




