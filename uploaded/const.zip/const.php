<?php
/**
* web24h.com.vn
*/
class sinhvien
{
	const NAME  = "Pham Kỳ Khôi";
	const EMAIL = "phamkykhoi.info@gmail.com";

	public function getEmail()
	{
		return SELF::EMAIL;
	}
}
$sinhvien = new sinhvien();
echo $sinhvien->getEmail();
//Kết quả là phamkykhoi.info@gmail.com
