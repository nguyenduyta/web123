<?php
	$product = array();
	$product[] = array(
						"id"    =>1,
						"name"  =>"Sony Xperia Z1",
						"price" =>"13990000"
				 );
	$product[] = array(
						"id"    =>2,
						"name"  =>"Nokia Lumia 1520",
						"price" =>"12000000"
				 );
	$product[] = array(
						"id"    =>3,
						"name"  =>"Iphone 4S",
						"price" =>"8000000"
				 );
	$product[] = array(
						"id"    =>4,
						"name"  =>"Samsung Galaxy Note 4",
						"price" =>"16000000"
				 );
	$product[] = array(
						"id"    =>5,
						"name"  =>"HTC Note Once",
						"price" =>"15000000"
				 );