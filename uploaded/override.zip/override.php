<meta charset="utf-8" />
<?php
/**
 * web24h.com.vn
 * Suntech
 */
class a
{
	public function getName()
	{
		echo "Nguyễn Văn A";
	}

	public function getEmail()
	{
		echo "aaa@gmail.com";
	}
}

class b extends a
{
	public function getPhone()
	{
		echo "Phone number: 0912.876.421";
	}

	public function getName()
	{
		parent::getName();
		echo "<br/>Nguyễn Văn B";
	}
}
//Khởi tạo đối tượng từ class b
$obj = new b();
$obj->getName(); //Kết quả là Nguyễn Văn B




