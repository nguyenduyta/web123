<meta charset="utf-8" />
<?php
/**
* web24h.com.vn
*/
class sinhvien
{
	public    $fullname = "Phạm Kỳ Khôi";
	public $email    = "phamkykhoi.info@gmail.com";
	public   $address  = "Hà Nội";
	public    $phone    = "0912.876.421";


	public function sleep()
	{
		return "Tôi đang ngủ";
	}

	public function talk()
	{
		return "Tôi đang nói chuyện";
	}

}
//Khởi tạo đội tượng
  $obj = new sinhvien();
//Truy cập đến thuộc tính và phương thức
  echo "<br/>".$obj->fullname;
  echo "<br/>".$obj->email;
  echo "<br/>".$obj->address;
  echo "<br/>".$obj->phone;
  echo "<br/>".$obj->sleep();
  echo "<br/>".$obj->talk();