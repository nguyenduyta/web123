<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Học PHP ở Hà Nội, Học PHP ở Hà Nội, Dao Tao PHP va MYSQL - Hoc PHP Online, Lap Trinh PHP, PHP can ban, PHP Nang Cao, PHP Framework, Hoc PHP MYSQL o Ha Noi, Hoc thiet ke web, Tu Hoc PHP, Hoc PHP De Hay Kho,PHP MYSQL can ban, Hoc PHP o Ha Noi, Hoc PHP MYSQL o dau</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Học PHP ở Hà Nội, Học PHP ở Hà Nội, Dao Tao PHP va MYSQL - Hoc PHP Online, Lap Trinh PHP, PHP can ban, PHP Nang Cao, PHP Framework, Hoc PHP MYSQL o Ha Noi, Hoc thiet ke web, Tu Hoc PHP, Hoc PHP De Hay Kho,PHP MYSQL can ban, Hoc PHP o Ha Noi, Hoc PHP MYSQL o dau" />
<meta name="description" content="Học PHP ở Hà Nội - PHP Căn Bản -  PHP Nâng Cao - PHP Framework, Học PHP ở Hà Nội, Dao Tao PHP va MYSQL - Hoc PHP Online, Lap Trinh PHP, PHP can ban, PHP Nang Cao, PHP Framework, Hoc thiet ke web, Tu Hoc PHP, Hoc PHP MYSQL o Ha Noi, Hoc PHP De Hay Kho,PHP MYSQL can ban, hoc lap trinh PHP o dau,Học PHP ở Hà Nội, Học Lập trình PHP MYSQL từ cơ bản đến nâng cao ở Hà Nội" />
<link type="text/css" href="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/styles/style.css" rel="stylesheet" />
<script type="text/javascript" src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/scripts/jquery-1.8.3.js"></script>
<script type="text/javascript" src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/scripts/cufon-yui.js"></script>
<script type="text/javascript" src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/scripts/UTM_Facebook_KT_400.font.js"></script>
<script type="text/javascript">
    Cufon.replace('#right_top_left ul a'); 
	Cufon.replace('#right_top_right span a'); 
    Cufon.replace('#menu_mid ul a'); 
	Cufon.replace('#product_top_title_left ul a'); 
	Cufon.replace('#category_menu_bottom ul a'); 
	Cufon.replace('#footer_bottom_menu ul a');
	Cufon.replace('#footer_bottom_copyright h4');
	Cufon.replace('.category_right_top_left	h3'); 	
</script>

<link rel="stylesheet" href="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/default/default.css" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/css/nivo-slider.css" type="text/css" media="screen" />
<script type="text/javascript" src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/js/jquery.nivo.slider.js"></script>
<script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });
</script>
</head>

<body>
<div id="top">
    <div id="header">
    	<div id="header_left">
        	<a href="index.html"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/logo.png" alt="H&T" title="H&T" id="logo" /></a>
        </div>
    	<div id="header_right">
        	<div id="header_right_top">
            	<div id="right_top_left">
                	<ul>
                		<li>
                			<a href="#">Đăng ký</a>
                			<a href="#">Đăng nhập</a>
                			<a href="#">Trợ giúp</a>
                		</li>
                	</ul>
                </div>
            	<div id="right_top_right"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/cart_home_icon.png" alt="Giỏ hàng" title="Giỏ hàng" /> <span><a href="#">Giỏ hàng</a></span></div>
                <div class="cls"></div>
            </div>
        </div>
        <div class="cls"></div>
    </div>
    <div id="menu">
     	<div id="menu_mid">
        	<ul>
        		<li>
        			<a href="#">Trang chủ</a>
        			<a href="#">Giới thiệu</a>
        			<a href="#">Áo đôi</a>
        			<a href="#">Quần đôi</a>
        			<a href="#">Đồ đôi khác</a>
        			<a href="#">Tư vấn</a>
        			<a href="#">Hỏi & đáp</a>
        			<a href="#">Bản đồ</a>
        			<a href="#">Liên hệ</a>
        		</li>
        	</ul>
        </div>
    </div>
</div>
<div id="slideshow">
	<div id="slider_showroom">
    	<div class="slider-wrapper theme-default">
            <div id="slider" class="nivoSlider">
                <img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/01.jpg" alt="" />
            </div>
        </div>
    </div>
</div>
<div style="clear:left"></div>
<div id="bottom">
    <div id="product_top">
    	<div id="product_top_title">
        	<div id="product_top_title_left">
            	<ul>
                	<li><a href="#" style="color:#FFF;">SẢN PHẨM XEM NHIỀU NHẤT</a></li>
                    <li><a href="#">SẢN PHẨM MỚI</a></li>
                    <li><a href="#">SẢN PHẨM KHUYẾN MẠI</a></li>
                </ul>
            </div>
            <div id="product_top_title_right">
            	<div class="view_all"><a href="#"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/view_all.png" /></a></div>
            </div>
            <div class="cls"></div>
        </div>
        <div id="product_bottom">
        	<div class="product_items"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product1.jpg" /><div class="new"></div></div>
            <div class="product_items"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product2.jpg" /><div class="promotion">Hot</div></div>
            <div class="product_items"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product3.jpg" /></div>
            <div class="product_items"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product4.jpg" /></div>
            <div class="product_items"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product5.jpg" /></div>
            <div class="product_items"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product1.jpg" /></div>
            <div class="cls"></div>
        </div>
    </div>  
    <div id="product_category">
    	<div id="product_category_left">
        	<div id="category_menu">
            	<div id="category_menu_top"></div>
                <div id="category_menu_bottom">
                	<ul>
                    	<li><a href="#">Khăn đôi</a></li>
                        <li><a href="#">Áo phông nam</a></li>
                        <li><a href="#">Áo khoác đôi</a></li>
                        <li><a href="#">Sơ mi đôi dài tay</a></li>
                        <li><a href="#">Quần sooc đôi</a></li>
                        <li><a href="#">Khăn đôi</a></li>
                        <li><a href="#">Áo phông nam</a></li>
                        <li><a href="#">Áo khoác đôi</a></li>
                        <li><a href="#">Sơ mi đôi dài tay</a></li>
                        <li><a href="#">Quần sooc đôi</a></li>
                        <li><a href="#">Khăn đôi</a></li>
                        <li><a href="#">Áo phông nam</a></li>
                        <li><a href="#">Áo khoác đôi</a></li>
                        <li><a href="#">Sơ mi đôi dài tay</a></li>
                        <li><a href="#">Quần sooc đôi</a></li>
                    </ul>
                </div>
            </div>
            <div id="category_support">
            	
            </div>
            <div id="category_fav">
            	<div id="category_fav_top"></div>
                <div id="category_fav_bottom">
                	<div class="pro_fav">
                    	<img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top1.jpg" width="100" height="100" />
                        <h5 class="pro_fav_name">Áo thun TN002</h5>
                        <h5 class="pro_fav_price">Giá : 550.000 vnd</h5>
                        <h5 class="pro_fav_fav">Người yêu thích : 198</h5>
                        <h5 class="pro_fav_buy">Đã mua : 120</h5>
                        <h5 class="pro_fav_cart"><a href="#"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/cart_fav_icon.png" /></a></h5>
                    </div>
                    <div class="pro_fav">
                    	<img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top1.jpg" width="100" height="100" />
                        <h5 class="pro_fav_name">Áo thun TN002</h5>
                        <h5 class="pro_fav_price">Giá : 550.000 vnd</h5>
                        <h5 class="pro_fav_fav">Người yêu thích : 198</h5>
                        <h5 class="pro_fav_buy">Đã mua : 120</h5>
                        <h5 class="pro_fav_cart"><a href="#"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>images/cart_fav_icon.png" /></a></h5>
                    </div>
                    <div class="pro_fav">
                    	<img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top1.jpg" width="100" height="100" />
                        <h5 class="pro_fav_name">Áo thun TN002</h5>
                        <h5 class="pro_fav_price">Giá : 550.000 vnd</h5>
                        <h5 class="pro_fav_fav">Người yêu thích : 198</h5>
                        <h5 class="pro_fav_buy">Đã mua : 120</h5>
                        <h5 class="pro_fav_cart"><a href="#"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/cart_fav_icon.png" /></a></h5>
                    </div>
                </div>
            </div>
        </div>
        <div id="product_category_right">
        	<div class="product_category">
                <div class="category_right_top">
                    <div class="category_right_top_left">
                        <h3>ÁO ĐÔI </h3>
                    </div>
                    <div class="category_right_top_mid"></div>
                    <div class="category_right_top_right">
                    	<div class="view_all"><a href="#"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/view_all.png" /></a></div>
                    </div>
                    <div class="cls"></div>
                </div>
                <div class="category_right_bottom">
                    <div class="pro_items">
                    	<div class="pro_items_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top1.jpg" /></div>
                        <div class="pro_items_cart">
                        	<div class="pro_items_name"><h3><a href="#">Áo thu đôi TN021</a></h3></div>
                            <div class="pro_items_cart_icon">
                            	<div class="cart_left"><h4>400.000 VND</h4></div>
                            </div>
                        </div>
                    </div>
                    <div class="pro_items">
                    	<div class="pro_items_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top2.jpg" /></div>
                        <div class="pro_items_cart">
                        	<div class="pro_items_name"><h3><a href="#">Áo thu đôi TN021</a></h3></div>
                            <div class="pro_items_cart_icon">
                            	<div class="cart_left"><h4>400.000 VND</h4></div>
                            </div>
                        </div>
                    </div>
                    <div class="pro_items">
                    	<div class="pro_items_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top3.jpg" /></div>
                        <div class="pro_items_cart">
                        	<div class="pro_items_name"><h3><a href="#">Áo thu đôi TN021</a></h3></div>
                            <div class="pro_items_cart_icon">
                            	<div class="cart_left"><h4>400.000 VND</h4></div>
                            </div>
                        </div>
                    </div>
                    <div class="pro_items">
                    	<div class="pro_items_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top4.jpg" /></div>
                        <div class="pro_items_cart">
                        	<div class="pro_items_name"><h3><a href="#">Áo thu đôi TN021</a></h3></div>
                            <div class="pro_items_cart_icon">
                            	<div class="cart_left"><h4>400.000 VND</h4></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="cls_padding"></div>
            <div class="product_category">
                <div class="category_right_top">
                    <div class="category_right_top_left">
                        <h3>QUẦN ĐÔI </h3>
                    </div>
                    <div class="category_right_top_mid"></div>
                    <div class="category_right_top_right">
                    	<div class="view_all"><a href="#"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/view_all.png" /></a></div>
                    </div>
                    <div class="cls"></div>
                </div>
                <div class="category_right_bottom">
                    <div class="pro_items">
                    	<div class="pro_items_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top1.jpg" /></div>
                        <div class="pro_items_cart">
                        	<div class="pro_items_name"><h3><a href="#">Áo thu đôi TN021</a></h3></div>
                            <div class="pro_items_cart_icon">
                            	<div class="cart_left"><h4>400.000 VND</h4></div>
                            </div>
                        </div>
                    </div>
                    <div class="pro_items">
                    	<div class="pro_items_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top2.jpg" /></div>
                        <div class="pro_items_cart">
                        	<div class="pro_items_name"><h3><a href="#">Áo thu đôi TN021</a></h3></div>
                            <div class="pro_items_cart_icon">
                            	<div class="cart_left"><h4>400.000 VND</h4></div>
                            </div>
                        </div>
                    </div>
                    <div class="pro_items">
                    	<div class="pro_items_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top3.jpg" /></div>
                        <div class="pro_items_cart">
                        	<div class="pro_items_name"><h3><a href="#">Áo thu đôi TN021</a></h3></div>
                            <div class="pro_items_cart_icon">
                            	<div class="cart_left"><h4>400.000 VND</h4></div>
                            </div>
                        </div>
                    </div>
                    <div class="pro_items">
                    	<div class="pro_items_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top4.jpg" /></div>
                        <div class="pro_items_cart">
                        	<div class="pro_items_name"><h3><a href="#">Áo thu đôi TN021</a></h3></div>
                            <div class="pro_items_cart_icon">
                            	<div class="cart_left"><h4>400.000 VND</h4></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="cls_padding"></div>
            <div class="product_category">
                <div class="category_right_top">
                    <div class="category_right_top_left">
                        <h3>ĐỒ BƠI ĐÔI </h3>
                    </div>
                    <div class="category_right_top_mid"></div>
                    <div class="category_right_top_right">
                    	<div class="view_all"><a href="#"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/view_all.png" /></a></div>
                    </div>
                    <div class="cls"></div>
                </div>
                <div class="category_right_bottom">
                    <div class="pro_items">
                    	<div class="pro_items_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top1.jpg" /></div>
                        <div class="pro_items_cart">
                        	<div class="pro_items_name"><h3><a href="#">Áo thu đôi TN021</a></h3></div>
                            <div class="pro_items_cart_icon">
                            	<div class="cart_left"><h4>400.000 VND</h4></div>
                            </div>
                        </div>
                    </div>
                    <div class="pro_items">
                    	<div class="pro_items_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top2.jpg" /></div>
                        <div class="pro_items_cart">
                        	<div class="pro_items_name"><h3><a href="#">Áo thu đôi TN021</a></h3></div>
                            <div class="pro_items_cart_icon">
                            	<div class="cart_left"><h4>400.000 VND</h4></div>
                            </div>
                        </div>
                    </div>
                    <div class="pro_items">
                    	<div class="pro_items_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top3.jpg" /></div>
                        <div class="pro_items_cart">
                        	<div class="pro_items_name"><h3><a href="#">Áo thu đôi TN021</a></h3></div>
                            <div class="pro_items_cart_icon">
                            	<div class="cart_left"><h4>400.000 VND</h4></div>
                            </div>
                        </div>
                    </div>
                    <div class="pro_items">
                    	<div class="pro_items_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top4.jpg" /></div>
                        <div class="pro_items_cart">
                        	<div class="pro_items_name"><h3><a href="#">Áo thu đôi TN021</a></h3></div>
                            <div class="pro_items_cart_icon">
                            	<div class="cart_left"><h4>400.000 VND</h4></div>
                            </div>
                        </div>
                    </div>
                    <div class="pro_items">
                    	<div class="pro_items_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top3.jpg" /></div>
                        <div class="pro_items_cart">
                        	<div class="pro_items_name"><h3><a href="#">Áo thu đôi TN021</a></h3></div>
                            <div class="pro_items_cart_icon">
                            	<div class="cart_left"><h4>400.000 VND</h4></div>
                            </div>
                        </div>
                    </div>
                    <div class="pro_items">
                    	<div class="pro_items_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top4.jpg" /></div>
                        <div class="pro_items_cart">
                        	<div class="pro_items_name"><h3><a href="#">Áo thu đôi TN021</a></h3></div>
                            <div class="pro_items_cart_icon">
                            	<div class="cart_left"><h4>400.000 VND</h4></div>
                            </div>
                        </div>
                    </div>
                    <div class="pro_items">
                    	<div class="pro_items_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top3.jpg" /></div>
                        <div class="pro_items_cart">
                        	<div class="pro_items_name"><h3><a href="#">Áo thu đôi TN021</a></h3></div>
                            <div class="pro_items_cart_icon">
                            	<div class="cart_left"><h4>400.000 VND</h4></div>
                            </div>
                        </div>
                    </div>
                    <div class="pro_items">
                    	<div class="pro_items_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/product_top4.jpg" /></div>
                        <div class="pro_items_cart">
                        	<div class="pro_items_name"><h3><a href="#">Áo thu đôi TN021</a></h3></div>
                            <div class="pro_items_cart_icon">
                            	<div class="cart_left"><h4>400.000 VND</h4></div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <div class="cls"></div>
    </div>
</div>	
<div id="footer">
	<div id="footer_top">
    	<div class="footer_top_3colum">
        	<div class="f3colum_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/logo_footer.jpg" /></div>
            <div class="f3colum_content">
            	Hơn 0h sáng, đường Hồ Huấn Nghiệp (phường Bến Nghé, quận 1) dài vài trăm mét đang rất náo nhiệt người qua lại. Hai vũ trường lớn là Gold Club 2 và VelVet vẫn hoạt động và khách ra vào tấp nập. Hàng trăm cảnh sát gồm nhiều lực lượng như CSGT, cơ động, hình sự... được huy động phong toả 2 đầu đường.
            </div>
        </div>
        <div class="footer_top_3colum">
        	<div class="f3colum_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/order_free.jpg" /></div>
            <div class="f3colum_content">
            	Hơn 0h sáng, đường Hồ Huấn Nghiệp (phường Bến Nghé, quận 1) dài vài trăm mét đang rất náo nhiệt người qua lại. Hai vũ trường lớn là Gold Club 2 và VelVet vẫn hoạt động và khách ra vào tấp nập. Hàng trăm cảnh sát gồm nhiều lực lượng như CSGT, cơ động, hình sự... được huy động phong toả 2 đầu đường.
            </div>
        </div>
        <div class="footer_top_3colum">
        	<div class="f3colum_img"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/after_order.jpg" /></div>
            <div class="f3colum_content">
            	Hơn 0h sáng, đường Hồ Huấn Nghiệp (phường Bến Nghé, quận 1) dài vài trăm mét đang rất náo nhiệt người qua lại. Hai vũ trường lớn là Gold Club 2 và VelVet vẫn hoạt động và khách ra vào tấp nập. Hàng trăm cảnh sát gồm nhiều lực lượng như CSGT, cơ động, hình sự... được huy động phong toả 2 đầu đường.
            </div>
        </div>
    </div>
	<div id="footer_bottom">
    	<div id="footer_bottom_menu">
        	<ul>
            	<li><a href="#">Trang chủ</a></li>
                <li><a href="#">Giới thiệu</a></li>
                <li><a href="#">Áo đôi</a></li>
                <li><a href="#">Đồ đôi khác</a></li>
                <li><a href="#">Tư vấn</a></li>
                <li><a href="#">Hỏi & đáp</a></li>
                <li><a href="#">Bản đồ</a></li>
                <li><a href="#">Liên hệ</a></li>
            </ul>
        </div>
        <div id="footer_bottom_copyright">
        	<h4>Copyright &copy; 2013 H&T COUPLE SHOP.Được thiết kế bởi Nguyễn Văn Trọng</h4>
        </div>
        <div id="footer_bottom_share"><img src="<?php echo base_url("public/doanhocvien/nguyenvantrong"); ?>/images/share.jpg"  /></div>
    </div>    
</div>
</body>
</html>
