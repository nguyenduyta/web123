<?php
/**
 * Created by PhpStorm.
 * User: KhoiPK
 * Date: 12/15/14
 * Time: 11:50 PM
 */
class index extends MY_Controller
{
    public function index()
    {
        echo __METHOD__
    }
}