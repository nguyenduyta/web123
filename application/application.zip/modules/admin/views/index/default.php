<div class="header">
<span><?php echo $title ?></span>
</div>
<br class="clear"/>
<div class="content">

Công ty TNHH NGC Việt Nam gửi lời chào, lời chúc thành công tới Quý khách hàng. 
Được thành lập vào năm 2009 –NGC Việt Nam là công ty hoạt động trong lĩnh vực thiết kế website,
xây dựng phần mềm doanh nghiệp, cung cấp các giải pháp công nghệ thông tin tại Việt Nam.
Với những bước đi chiến lược đúng đắn, NGC Việt Nam hiện là nhà cung cấp dịch vụ thiết kế web,
xây dựng phần mềm có thị phần lớn tại Việt Nam. NGC Việt Nam Với đội ngũ nguồn nhân lực trẻ, năng động,
các chuyên viên tư vấn nhiệt tình, tâm huyết với công việc và có trình độ chuyên môn cao đã luôn có được sự hài
lòng của tất cả các khách hàng và doanh nghiệp. Với định hướng phát triển lâu dài trong lĩnh vực Công nghệ thông tin. 
Mục tiêu của NGC Việt Nam là tạo ra những công cụ quản lý - điều hành hiệu quả cho các tổ chức, các công cụ hỗ trợ bán 
hàng đắc lực cho doanh nghiệp, để từ đó mang lại sự chuyên nghiệp cho toàn bộ quý khách hàng mà chúng tôi đã và đang cung cấp dịch vụ.<br />


<strong>CHỨC NĂNG CỦA WEBSITE :</strong><br />

Quản trị thành viên, gian hàng, thông tin...<br />
Sửa xóa cập nhật dữ liệu toàn bộ website...<br />
Quản trị thành viên, gian hàng, thông tin...<br />
</div>