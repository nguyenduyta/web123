<div id="header">
	<div id="logo">
			
	</div>
	<div id="account_info">
		<img src="<?php echo base_url() ?>public/admin/images/icon_online.png" alt="Online" class="mid_align" />
		Xin chào <a href=""><?php echo $_SESSION['admin']; ?></a> | <a target="_blank" href="<?php echo site_url('index') ?>">Xem trang chủ</a> | <a href="<?php echo base_url()."admin/login/logout" ?>">Thoát</a>
	</div>
</div>