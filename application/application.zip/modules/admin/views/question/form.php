<script type="text/javascript">
    $(document).ready(function(){
        $("#ques_content").val();
    })
</script>
<div class="onecolumn">
<form id="form_data" name="form_data" action="" method="post" enctype="multipart/form-data">
<div class="header">
	<span style="float:left; width:70%;"><?php if(isset($title)){ echo $title; } ?></span>
    <span style="float:right; margin-right:15px;">
    	<ul id="control" style="margin:0px; padding:0px; list-style:none;">
            <li>
                <input type="hidden" name="isSubmit" value="1" />
                <input type="submit" name="btnAdd" value="Save" />&nbsp;
                <input type="reset" name="btnReset" value="Cancel" onclick="location.href='/admin/exam'" />
            </li>
        </ul>
    </span>
</div>
<br class="clear"/>
<div class="content" style="min-height:400px;">
    <div class="gt">
        <table class="data" width="100%" cellpadding="0">
            <tr>
                <td align="center">Chú ý: (<span class="require">*</span>)bắt buộc nhập thông tin</td>
            </tr>
        </table>
		<table class="data" width="100%" cellpadding="0" cellspacing="0">
        		<tbody>
        		<tr>
                  <td width="125" style="vertical-align:middle;">
                    <label>Nội dung câu hỏi&nbsp;(<span class="require">*</span>)</label></td>
                    <td>
                      <?php 
                        $info_desc = isset($infoQuestion['ques_content']) && $infoQuestion['ques_content'] != null 
                                        ? $infoQuestion['ques_content'] : $this->input->post("ques_content");
                        $fck = new FCKeditor('ques_content');
                        $fck->BasePath = sBASEPATH;
                        $fck->Value  = $info_desc;
                        $fck->Width  = '100%';
                        $fck->Height = 180;
                        $fck->ToolbarSet = 'Basic';
                        $fck->Create();
                      ?>
                      <?php echo form_error('ques_content') ?>
                    </td>
        		</tr>
                <?php 
                    if(isset($answerInfo) && $answerInfo != null): 
                        foreach($answerInfo as $key=>$value):
                ?>
                <tr>
                  <td width="125" style="vertical-align:middle"><label>Đáp án 1</label></td>
                  <td>
                    <?php 
                        $info_desc = isset($value['ans_content']) && $value['ans_content'] != null 
                                        ? $value['ans_content'] : "";
                        $fck = new FCKeditor('answer['.$value['id'].']');
                        $fck->BasePath = sBASEPATH;
                        $fck->Value  = $info_desc;
                        $fck->Width  = '100%';
                        $fck->Height = 120;
                        $fck->ToolbarSet = 'Basic';
                        $fck->Create();
                    ?>
                  </td>
                </tr>
                <?php endforeach; endif;  ?>
                <!-- <tr>
                  <td width="125" style="vertical-align:middle"><label>Đáp án 2</label></td>
                  <td>
                    <?php 
                        $info_desc = isset($answerInfo[1]['ans_content']) && $answerInfo[1]['ans_content'] != null 
                                        ? $answerInfo[1]['ans_content'] : $this->input->post("answer_1");
                        $fck = new FCKeditor('answer[]');
                        $fck->BasePath = sBASEPATH;
                        $fck->Value  = $info_desc;
                        $fck->Width  = '100%';
                        $fck->Height = 120;
                        $fck->ToolbarSet = 'Basic';
                        $fck->Create();
                    ?>
                  </td>
                </tr>
                <tr>
                  <td width="125" style="vertical-align:middle"><label>Đáp án 3</label></td>
                  <td>
                    <?php 
                        $info_desc = isset($answerInfo[2]['ans_content']) && $answerInfo[2]['ans_content'] != null 
                                        ? $answerInfo[2]['ans_content'] : $this->input->post("answer_1");
                        $fck = new FCKeditor('answer[]');
                        $fck->BasePath = sBASEPATH;
                        $fck->Value  = $info_desc;
                        $fck->Width  = '100%';
                        $fck->Height = 120;
                        $fck->ToolbarSet = 'Basic';
                        $fck->Create();
                    ?>
                  </td>
                </tr>
                <tr>
                  <td width="125" style="vertical-align:middle"><label>Đáp án 4</label></td>
                  <td>
                    <?php 
                       $info_desc = isset($answerInfo[3]['ans_content']) && $answerInfo[3]['ans_content'] != null 
                                        ? $answerInfo[3]['ans_content'] : $this->input->post("answer_1");
                        $fck = new FCKeditor('answer[]');
                        $fck->BasePath = sBASEPATH;
                        $fck->Value  = $info_desc;
                        $fck->Width  = '100%';
                        $fck->Height = 120;
                        $fck->ToolbarSet = 'Basic';
                        $fck->Create();
                    ?>
                  </td>
                </tr> -->
                <tr>
                      <td width="125" style="vertical-align:middle"><label>Thuộc đề thi</label></td>
                      <td> 
                         <ul>
                            <?php 
                                if (isset($examList) && $examList != null):
                                    foreach ($examList as $key => $value) {
                                        if(isset($exam) && $exam != null ) {
                                            if(in_array($value['id'], $exam)) {
                                                $checked = "checked='checked'";
                                            } else {
                                                $checked = "";
                                            }
                                        } else {
                                            $checked = "";
                                        }
                                        echo '<li><input type="checkbox" name="exam[]" value="'.$value['id'].'" '.$checked.' />'.$value['name'].'</li>';
                                    }
                                endif;
                            ?>
                         </ul>
                         <p style="color:red;"><?php echo isset($errorExam) ? $errorExam : ""; ?></p>
                      </td>
                </tr>
                <tr>
                    <td width="125" style="vertical-align:middle"><label>Status</label></td>
                    <td>
                        <select name="ques_status">
                            <option value="0">Enable</option>
                            <option value="1">Disable</option>
                        </select>
                    </td>
                </tr>
		  </tbody>
		</table>
	<!-- End bar chart table-->
  </div>
</div>
</form>
</div>