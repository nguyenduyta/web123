<link href="<?php echo base_url() ?>public/admin/css/blue/screen.css" rel="stylesheet" type="text/css" media="all">
<link href="<?php echo base_url() ?>public/admin/css/blue/datepicker.css" rel="stylesheet" type="text/css" media="all">
<link href="<?php echo base_url() ?>public/admin/js/visualize/visualize.css" rel="stylesheet" type="text/css" media="all">
<link href="<?php echo base_url() ?>public/admin/js/jwysiwyg/jquery.wysiwyg.css" rel="stylesheet" type="text/css" media="all">
<link href="<?php echo base_url() ?>public/admin/js/fancybox/jquery.fancybox-1.3.0.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="<?php echo base_url() ?>public/jpage/css/jPages.css" type="text/css" />

<!--[if IE]>
	<link href="<?php echo base_url() ?>public/admin/css/ie.css" rel="stylesheet" type="text/css" media="all">
	<meta http-equiv="X-UA-Compatible" content="IE=7" />
<![endif]-->