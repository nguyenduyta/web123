<?php 
/**
* KhoiPK
* Class Exam Model
*/
class question_model extends CI_Model
{
	protected $table = "tbl_question";

	public function listQuestion()
	{
		return $this->db->get($this->table)->result_array();
	}

	public function insertQuestion($dataQuestion, $dataExam, $answerData)
	{
		//Insert Question
		$this->db->insert($this->table, $dataQuestion);
    	$quesId = $this->db->insert_id();

    	//Insert Exam
    	$dataExamQues = array("ques_id" => $quesId);
    	foreach ($dataExam as $key => $value) {
    		$dataExamQues['exam_id'] = $value;
    		$this->db->insert("exam_question", $dataExamQues);
    	}

    	//Insert Answer
    	$dataAnswer = array(
    					"ques_id" => $quesId,
    					"status"  =>0
    				  );
    	foreach ($answerData as $valueAnswer) {
    		$dataAnswer['ans_content'] = $valueAnswer;
    		$this->db->insert("tbl_answer", $dataAnswer);
    	}
	}

	public function updateQuestion($dataQuestion, $dataExam, $answerData,$id)
	{
		// echo "<pre>";
		// print_r($answerData);
		// echo "</pre>";
		foreach($answerData as $keyAnswer=>$valueAnswer) {
			$this->db->where("id",$keyAnswer);
			$this->db->update("tbl_answer",array("ans_content" => $valueAnswer));
		}
	}

	public function getOnce($id)
	{
		$data = $this->db->select("tbl_question.id,tbl_question.ques_content,tbl_question.ques_status")
				 ->from($this->table)
				 ->where("tbl_question.id",$id)
				 ->join("tbl_answer", "tbl_answer.ques_id = tbl_question.id", "left")
				 ->get()->row_array();

		$data['answer'] = $this->db->where("ques_id",$id)
								   ->order_by("id","ASC")
								   ->get("tbl_answer")
								   ->result_array();
		$data['exam']   = $this->db->where("ques_id",$id)
								   ->order_by("id","ASC")
								   ->get("exam_question")
								   ->result_array();
		return $data;
	}
}