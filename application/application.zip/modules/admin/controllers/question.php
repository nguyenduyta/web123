<?php
/**
* Class Question
* KhoiPK
* 17/03/2014
*/
class question extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model("exam_model");
		$this->load->model("question_model");
	}
	public function index()
	{

		$data = array();
		$data['listQuestin'] = $this->question_model->listQuestion();
		$data['title'] 	     = "Danh sách câu hỏi";
		$data['template']    = "question/list";
    	$this->load->view("layout",$data);
	}

	public function create()
	{

		if($this->input->post("btnAdd")) {
			if(!$this->validation() || !isset($_POST['exam']) || $_POST['exam'] == null ) {
				$errorExam = "Vui lòng chọn đề thì";
			} else {
				$formData 		= $this->getFormDataQuestion();
				$formAnswerData = $this->input->post('answer'); 
				echo "<pre>";
				print_r($formAnswerData);
				echo "</pre>";
				die;
				$this->question_model->insertQuestion($formData, $_POST['exam'], $formAnswerData);
			}
		}
		$data['exam'] = isset($_POST['exam']) ? $_POST['exam'] : array();
		$data['examList']  = $this->exam_model->getAll();
		$data['title'] 	   = "Thêm câu hỏi";
		$data['template']  = "question/form";
		$data['errorExam'] = isset($errorExam) ? $errorExam : "";
    	$this->load->view("layout",$data);
	}

	public function update($id)
	{
		if($this->input->post("btnAdd")) {
			if(!$this->validation() || !isset($_POST['exam']) || $_POST['exam'] == null ) {
				$errorExam = "Vui lòng chọn đề thì";
			} else {
				$formData 		= $this->getFormDataQuestion();
				$formAnswerData = $this->input->post('answer');
				$examDataForm   = $this->input->post('exam');

				$this->question_model->updateQuestion($formData, $examDataForm, $formAnswerData, $id );
			}
		}

		$data['errorExam']    = isset($errorExam) ? $errorExam : "";
		$data['examList']     = $this->exam_model->getAll();
		$data['infoQuestion'] = $this->question_model->getOnce($id);
		$data['answerInfo']   = $data['infoQuestion']['answer'];

		if(isset($data['infoQuestion']['exam']) && $data['infoQuestion']['exam'] != null ) {
			foreach ($data['infoQuestion']['exam'] as $key => $value) {
				$data['exam'][] = $value['exam_id'];
			}
		}

		$data['title']        = "Sửa câu hỏi";
		$data['template']     = "question/form";
		$this->load->view("layout",$data);	
	}

	private function getFormDataQuestion()
	{
		$data = array(
					"ques_content" => $this->input->post("ques_content"), 
					"ques_status"  => $this->input->post("ques_status")
				);
		return $data;
	}

	public function validation()
    {
        $this->form_validation->set_rules("ques_content","Nội dung câu hỏi","trim|required");

        $this->form_validation->set_message('required', '%s không được để trống');          
        $this->form_validation->set_message("min_length","%s không được nhỏ hơn %d kí tự");
        $this->form_validation->set_message("max_length","%s không được lớn hơn %d kí tự");
        $this->form_validation->set_message('matches', '%s không trùng nhau');
        $this->form_validation->set_message("valid_email","%s không đúng định dạng");
        $this->form_validation->set_message("numeric","%s phải là định dạng số");
        $this->form_validation->set_error_delimiters('<div class="error">','</div>');
        
        if($this->form_validation->run()) {
        	return true;
        } else {
        	return false;
        }
    }
}