<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN" "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">
<!-- saved from url=(0070)http://s.qplay.vn/626-0-0-0--1/game/Dau-truong-tri-tue.html#&slider1=2 -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<title>Đấu trường trí tuệ</title>    
<link rel="shortcut icon" href="http://s.qplay.vn/images/layoutv2/favicon.ico"/>
<link rel="icon" href="http://s.qplay.vn/images/layoutv2/favicon.ico"/>   
<meta name="viewport" content="width=device-width; initial-scale=1.0;  maximum-scale=1.0"/>
<meta name="format-detection" content="telephone=no"/>
<meta http-equiv="collapsable" content="none"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black"/>
<meta name="keywords" content="game mien phi, game cho android, down game android, miễn phí"/>
<meta name="description" content="Game mien phi và ứng dụng cho android"/>
<meta property="og:title" content="Sản phẩm &quot; Đấu trường trí tuệ&quot;"/>
<meta property="og:description" content="Game miễn phi và ứng dụng cho android"/>
<meta property="og:type" content="author"/>
<meta property="og:image" content="http://s.qplay.vn//images/product/icon/72261013-084720.png"/>
<meta property="og:site_name" content="s.qplay.vn"/>
<meta property="fb:admins" content="100001127973338"/>
<meta name="keywords" content="Đấu trường trí tuệ"/>    
<script type="text/javascript" async="" src="<?php echo base_url() ?>public/taigame/js/ga.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>public/taigame/js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>public/taigame/js/jquery.rating.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>public/taigame/js/jquery.movingboxes.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>public/taigame/js/screen_shot.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>public/taigame/js/comment.js"></script>    
<script type="text/javascript" src="<?php echo base_url() ?>public/taigame/js/default.js"></script>
<link href="<?php echo base_url() ?>public/taigame/css/facebook.css" media="screen" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url() ?>public/taigame/css/movingboxes.css" media="screen" rel="stylesheet" type="text/css"/> 
<link type="text/css" rel="stylesheet" href="<?php echo base_url() ?>public/taigame/css/default.css"/>       
</head>
<body>
	<div id="wapper">
	<input type="hidden" name="channel" value="" id="channel">	
    <div class="top-sticky-div">
		<div id="topheader">
				<a href="http://s.qplay.vn/1/0-0-0--1/3s/tot-nhat.html" id="logo">
                <img id="main-logo" src="<?php echo base_url() ?>public/taigame/images/logo_bk.png"/></a>
				<div id="right_top" align="right">
                    <ul id="small_menu">
                        <!--<li class="li_2">
                            <a class="t_search li_2" onclick="load_bottom(&#39;t_search&#39;,&#39;/index/search-form&#39;,&#39;t_login&#39;,&#39;/index/login-form&#39;)">
                                <img class="top_menu" src="images/search.png" onmouseover="this.src=images/search2.png" onmouseout="this.src=images/search.png"/>
                            </a>
                        </li>
                        <li class="li_2">
                            <a class="t_login li_2" onclick="load_bottom(&#39;t_login&#39;,&#39;/index/login-form&#39;,&#39;t_search&#39;,&#39;/index/search-form&#39;)">
                                <img class="top_menu" src="images/login.png" onmouseover="this.src=images/login2.png;" onmouseout="this.src=images/login.png"/>
                            </a>
                        </li>-->                                 
                        <li class="li_2" id="t_menu">
                            <a class="t_catalog li_2" onclick="menu_hover()">
                                <img class="top_menu" src="<?php echo base_url() ?>public/taigame/images/catalog.png" onmouseover="this.src=<?php echo base_url() ?>public/taigame/images/catalog2.png" onmouseout="this.src=<?php echo base_url() ?>public/taigame/images/catalog.png"/>
                            </a>
                            <ul id="menu_hover">
                                <li class=" li_1 " onclick="window.location=/1/0-0-0--1/3s/game.html">
                                    <img class="icon_topmenu" src="<?php echo base_url() ?>public/taigame/images/game281112-122710.png"/>
                                    <a>Game</a>
                                    <img class="hover_menu" src="images/mui_ten.png"/>
                                </li>
                                <li class=" li_1 " onclick="window.location=/1/0-0-0--1/3s/ung-dung.html">
                                    <img class="icon_topmenu" src="<?php echo base_url() ?>public/taigame/images/ungdung281112-122723.png"/>
                                    <a>Ứng dụng</a>
                                    <img class="hover_menu" src="<?php echo base_url() ?>public/taigame/images/mui_ten.png"/>
                                </li>
                                <li class=" li_1 " onclick="window.location=/index/send-email">
                                    <img class="icon_topmenu" src="<?php echo base_url() ?>public/taigame/images/phanhoi281112-122732.png"/>
                                    <a>Phản hồi</a>
                                    <img class="hover_menu" src="<?php echo base_url() ?>public/taigame/images/mui_ten.png"/>
                                </li>                              
                                <li class="li_1" onclick="requires_login2(&#39;/0-0-0--1/thegame.html&#39;)">
                                    	<img class="icon_topmenu" src="<?php echo base_url() ?>public/taigame/images/card.png">
                                    	<a>Nhận thẻ game</a>
	                                    <img class="hover_menu" src="<?php echo base_url() ?>public/taigame/images/mui_ten.png">
                               </li>
                               <li class="li_1" onclick="window.location=&#39;/1/0-0-0--1/3s/free.html&#39;">
                               		<img class="icon_topmenu" src="<?php echo base_url() ?>public/taigame/images/game-free.png">
	                               <a href="http://s.qplay.vn/1/0-0-0--1/3s/free.html">Game miễn phí</a>
	                               <img class="hover_menu" src="<?php echo base_url() ?>public/taigame/images/mui_ten.png">
	                           </li>
                    </ul>
                </li>
            </ul>
        </div>
		</div>
        <div id="bottom_header"></div>
        <div id="menu">
		<table id="table_menutop" border="0" cellspacing="0" cellpadding="0">
            <tbody><tr>
                <td>
                    <a id="menu_top1" href="http://s.qplay.vn/1/0-0-0--1/2s/moi-nhat.html" class=" menu_top ">
                    	Mới nhất
                    </a>
                </td>
            	<td>
                    <a id="menu_top2" href="http://s.qplay.vn/1/0-0-0--1/1s/hot-nhat.html" class=" menu_top  menu_top_center">
                    	Hot nhất
                    </a>
                </td>
            	<td>
                    <a id="menu_top3" href="http://s.qplay.vn/1/0-0-0--1/3s/tot-nhat.html" class=" menu_top  menu_top_last">
                    	Tốt nhất
                    </a>
                </td>
                </tr>
            </tbody>
        </table>		
    </div>
<div id="main">
<input type="hidden" name="resolution_width" value="800" id="resolution_width"/>
<div class="poster">
    <img src="<?php echo base_url() ?>public/taigame/images/480x235261013-084734.jpg" id="poster"/>
</div>
	<!-- View category -->
		<center>
		<div class="category">						
            <a class="a_category " href="http://s.qplay.vn/1/0-0-0--1/3s/0/tot-nhat/tat-ca.html"><span class="category_name">Tất cả</span></a>
		    <a class="a_category " href="http://s.qplay.vn/1/0-0-0--1/3s/3/tot-nhat/nhap-vai.html"><span class="category_name">Nhập vai</span></a>
		    <a class="a_category " href="http://s.qplay.vn/1/0-0-0--1/3s/4/tot-nhat/phieu-luu.html"><span class="category_name">Phiêu lưu</span></a>
		    <a class="a_category " href="http://s.qplay.vn/1/0-0-0--1/3s/5/tot-nhat/the-thao.html"><span class="category_name">Thể thao</span></a>
		</div>									
        <div class="category">						
            <a class="a_category " href="http://s.qplay.vn/1/0-0-0--1/3s/7/tot-nhat/tri-tue.html"><span class="category_name">Trí tuệ</span></a>
    		<a class="a_category " href="http://s.qplay.vn/1/0-0-0--1/3s/8/tot-nhat/ban-sung.html">
            <span class="category_name">Bắn súng</span>
    		<span class="notification "><span class="in_no">1 </span></span>						
            </a>
    		<a class="a_category " href="http://s.qplay.vn/1/0-0-0--1/3s/11/tot-nhat/giai-tri.html"><span class="category_name">Giải trí</span>
    		<span class="notification "><span class="in_no">3 </span></span>						
            </a>
    		<a class="a_category " href="http://s.qplay.vn/1/0-0-0--1/3s/12/tot-nhat/chien-thuat.html"><span class="category_name">Chiến thuật</span></a>
		</div>									
        <div class="category">						
            <a class="a_category " href="http://s.qplay.vn/1/0-0-0--1/3s/14/tot-nhat/dua-xe.html"><span class="category_name">Đua xe</span></a>
		    <a class="a_category " href="http://s.qplay.vn/1/0-0-0--1/3s/15/tot-nhat/am-nhac.html"><span class="category_name">Âm nhạc</span></a>
		    <a class="a_category " href="http://s.qplay.vn/1/0-0-0--1/3s/1/tot-nhat/mo-phong.html"><span class="category_name">Mô phỏng</span></a>
		    <a class="a_category " href="http://s.qplay.vn/1/0-0-0--1/3s/16/tot-nhat/online.html"><span class="category_name">Online</span>
		      <span class="notification noti3"><span class="in_no">1 </span></span>						
            </a>
		</div>								
    </center>
<div class="div_lienquan div_boder">
        			<div class="row2 clearfix row2_1">
	        			 <div class="left">
	        				<a href="http://s.qplay.vn/269-0-0-0--1/game/Ban-cung-sieu-dang.html"><img src="images/72 (1)081212-092706.png" class="icon"/></a>
	        			</div>
	        			<div class="right right1_0" align="right">
                            <a href="http://s.qplay.vn/269-0-0-0--1/game/Ban-cung-sieu-dang.html"></a>
                        
	        			</div>
	        			<div id="info">
	        					<a href="http://s.qplay.vn/269-0-0-0--1/game/Ban-cung-sieu-dang.html"><b class="name"><span>Bắn cung siêu đẳng</span></b></a>
	        					<span class="mid_info">Bắn cung môn thể thao dân tộc lại 1 lần nữa được nhắc đến và tái hiện lại trong trò chơi cùng tên. Bạn có phải là 1 xạ thủ xuất sắc không. Nếu phải thì cùng thử sức nhé.
Cách chơi:
- Ngắm bắn thật chuẩn
- Với nhiều mức độ chơi từ dễ đến khó
- Bảng xếp hạng được update liên tục
Hãy cùng so tài nhé các bạn.</span>
                                <span class="bottom_info"><img src="<?php echo base_url() ?>public/taigame/images/tim.png">148<img src="images/tai.png" style="margin-left:  15px;"/>17,111</span>
	        			</div>
                        <a class="download_1" href="http://s.qplay.vn/269-0-0-0--1/download/Ban-cung-sieu-dang.html"><span>Tải xuống</span></a>
        			</div>
        			<div class="row2 clearfix row2_2">
	        			 <div class="left">
	        				<a href="http://s.qplay.vn/587-0-0-0--1/game/Lua-bo.html"><img src="<?php echo base_url() ?>public/taigame/images/72 x 72180913-092221.png" class="icon"/></a>
	        			</div>
	        			<div class="right right1_1" align="right">
                            <a href="http://s.qplay.vn/587-0-0-0--1/game/Lua-bo.html"></a>
                        
	        			</div>
	        			<div id="info">
	        					<a href="http://s.qplay.vn/587-0-0-0--1/game/Lua-bo.html"><b class="name"><span>Lùa bò</span></b></a>
	        					<span class="mid_info">Vào vai một người quản nông trại bò, công việc hằng ngày tưởng như đơn giản là lùa bò vào chuồng nay khó khăn hơn với sự tấn công không ngừng của Ailens, những kẻ đến từ ngoài trái đất. Công việc của bạn là lùa thật nhanh đàn bò và ngăn cản không cho Ailens vào chuồng bằng bất cứ giá nào để bảo vệ cả đàn bình yên vô sự. Đàn bò đều trông chờ vào đôi bàn tay khéo léo của bạn đấy.
Với lỗi chơi mới lạ, đồ họa đẹp mắt công thêm hiệu ứng âm thanh thật sự khác biệt, game sẽ mang lại cho bạn một cảm khác mới mẻ. Vậy còn chờ gì nữa mà không down game vè play ngay!</span>
                                <span class="bottom_info"><img src="<?php echo base_url() ?>public/taigame/images/tim.png"/>9<img src="<?php echo base_url() ?>public/taigame/images/tai.png" style="margin-left:  15px;"/>963                                    
                                </span>
                                
	        			</div>
                        <a class="download_1" href="http://s.qplay.vn/587-0-0-0--1/download/Lua-bo.html"><span>Tải xuống</span></a>
        			</div>
        			<div class="row2 clearfix row2_1">
	        			 <div class="left">
	        				<a href="http://s.qplay.vn/36-0-0-0--1/game/Ai-la-trieu-phu-(80000-cau-hoi).html"><img src="<?php echo base_url() ?>public/taigame/images/2446805789ai-la-trieu-phu-offline.png" class="icon"></a>
                            
	        			</div>
	        			<div class="right right1_2" align="right">
                            <a href="http://s.qplay.vn/36-0-0-0--1/game/Ai-la-trieu-phu-(80000-cau-hoi).html"></a>
                        
	        			</div>
	        			<div id="info">
	        					<a href="http://s.qplay.vn/36-0-0-0--1/game/Ai-la-trieu-phu-(80000-cau-hoi).html"><b class="name"><span>Ai là triệu phú (80000 câu hỏi)</span></b></a>
	        					<span class="mid_info">Bạn rất yêu thích game show Ai là triệu phú trên VTV3 nhưng lại chưa có cơ hội được tham gia?</span>
                                <span class="bottom_info"><img src="<?php echo base_url() ?>public/taigame/images/tim.png"/>597<img src="<?php echo base_url() ?>public/taigame/images/tai.png" style="margin-left:  15px;"/>176,637                                    
                                </span>
                                
	        			</div>
                        <a class="download_1" href="http://s.qplay.vn/36-0-0-0--1/download/Ai-la-trieu-phu-(80000-cau-hoi).html"><span>Tải xuống</span></a>
        			</div>
        			<div class="row2 clearfix row2_2">
	        			 <div class="left">
	        				<a href="http://s.qplay.vn/584-0-0-0--1/game/Xam-luoc-trai-dat.html"><img src="<?php echo base_url() ?>public/taigame/images/icon-72180913-050430.png" class="icon"></a>
                            
	        			</div>
	        			<div class="right right1_3" align="right">
                            <a href="http://s.qplay.vn/584-0-0-0--1/game/Xam-luoc-trai-dat.html"></a>
                        
	        			</div>
	        			<div id="info">
	        					<a href="http://s.qplay.vn/584-0-0-0--1/game/Xam-luoc-trai-dat.html"><b class="name"><span>Xâm lược trái đất</span></b></a>
	        					<span class="mid_info">Năm 2025, ngày tận thế trái đất đã đến, hiệu ứng nhà kính đã khiến cho băng tan, khí hậu thay đổi, lũ lụt, hạn hán xảy ra ở khắp nơi. Trước những hành động phá hủy trái đất của loài người, những người krypton không thể chịu đựng nổi. Ngày XX tháng YY năm ZZZZ, những chiếc đĩa bay của người krypton đến trái đất xâm lược để ngăn chặn sự tàn phá này. Trong game, bạn sẽ là người ngoài hành tinh bắn phá hủy diệt loài người. 
Game có đồ họa chi bi, âm thanh sống động. Hãy cùng down game về để thưởng thức nhé.</span>
                                <span class="bottom_info"><img src="<?php echo base_url() ?>public/taigame/images/tim.png">18<img src="<?php echo base_url() ?>public/taigame/images/tai.png" style="margin-left:  15px;">1,049                                    
                                </span>
                                
	        			</div>
                        <a class="download_1" href="http://s.qplay.vn/584-0-0-0--1/download/Xam-luoc-trai-dat.html"><span>Tải xuống</span></a>
        			</div>
	<hr class="hr2">	
</div>
<input type="hidden" value="/index/vote?id=626&amp;/626-3-0-0--1/Game/Dau-truong-tri-tue.html" id="link">
<!-- Hien thi danh sách sản phẩm liên quan-->
		</div>
		<div id="partition" class="bar1" style="display:none;">
	            <div class="p_left">
	            	<a class="preview"></a>
	            </div>
	            <center class="p_center loading-gif"></center>
	            <div class="p_right" align="right">
	            	<a class="next"></a>
                    </div>
		</div><!--end #partition-->
		<div class="bottom-space"></div>
		<div class="bottom-sticky-div">
	
        <!-- <div id="partition" class="bar1">
        	<a class="submenu" href="http://home.newsqplay.vn:88">Tất cả</a> | 
        	<a class="submenu" href="http://home.newsqplay.vn:88">Tin tức</a> | 
        	<a class="submenu" href="http://home.newsqplay.vn:88">Bình luận</a> | 
        	<a class="submenu" href="http://home.newsqplay.vn:88">Sự kiện</a>
        </div> -->
        <div id="banner">
			<a href="http://s.qplay.vn/342-0-0-0--1/game/Hoang-de.html" target="_blank">
            <img src="<?php echo base_url() ?>public/taigame/images/480x107120313-030051.jpg"></a>
		</div>
		        
        <div id="bottom">
            <div class="b_right">
                <a href="mailto:cskh@sunnet.vn" id="supportLink" class="b_mail">
                   <img src="<?php echo base_url() ?>public/taigame/images/mail.png"> 
                </a>
                <a href="tel: +84435766085" class="b_tel">
                    <img src="images/phone1.png">
                </a>
                <a href="http://s.qplay.vn/626-0-0-0--1/game/Dau-truong-tri-tue.html#" class="b_tel">
                    <img src="<?php echo base_url() ?>public/taigame/images/top-hover.png">
                </a>
            </div>
            <!-- <a class="b_logo">
                <img src="/images/layoutv2/logo-bottom.png"/>
            </a> -->
            
        </div><!--end #bottom-->
        </div>
		<div id="menubottom">
		<!--<a href="http://s.qplay.vn">Top game android</a> | <a href="http://s.qplay.vn">game android moi</a> | <a href="http://s.qplay.vn/?type=1">game android</a> | <a href="http://s.qplay.vn/?type=1">Tai game android</a> | <a href="http://s.qplay.vn/?type=1">Tai game android</a> | <a href="http://s.qplay.vn/?type=1">android game</a> | <a href="http://s.qplay.vn/?type=1">cai dat game android</a> | <a href="http://s.qplay.vn">game android hay</a> | <a href="http://s.qplay.vn/?type=1">game di canh android</a> | <a href="http://s.qplay.vn">game android vui</a> | <a href="http://s.qplay.vn">game hay android</a> | <a href="http://s.qplay.vn/?type=1">game dinh cho android</a> | <a href="http://s.qplay.vn/?type=1">tong hop game android</a> | <a href="http://s.qplay.vn/?type=1">game cho dien thoai android</a> | <a href="http://s.qplay.vn/?type=1">tai game cho android</a> | <a href="http://s.qplay.vn/?type=1">game for android</a> | <a href="http://s.qplay.vn/?type=1">game android 2 3</a> | <a href="http://s.qplay.vn/?type=1">game android 2 2</a> | <a href="http://s.qplay.vn/?type=1">game android 2 1</a>-->
<style type="text/css">
    #menubottom a{
    	display: inline-block;
        padding: 5px;
        font-weight: bold;
    }
</style>
<a href="http://s.qplay.vn/bai-viet/lien-he.html">Liên hệ</a> | 
<a href="http://s.qplay.vn/bai-viet/chinh-sach.html">Chính sách người dùng</a> | 
<a href="http://s.qplay.vn/bai-viet/cai-dat.html">Cài đặt và Xoá phần mềm</a>

		</div>
		<div class="info clearfix term-added" style="display:none;">
			<span class="about"><div style="text-align: justify; ">
				<font size="2">Các game trên trang web được tải miễn phí và cài đặt miễn phí.</font></div>
									<div style="text-align: justify; ">
				<font size="2">Billing Interval:</font></div>
				<div style="text-align: justify; ">
				<font size="2">Tuy nhiên để có thể có thể chơi lên cấp độ cao hơn, thứ hạng cao trong game như trang bị đồ xịn hơn, nhiều bảo vật hơn, nhân vật có nhiều ưu thế hơn thì người dùng sẽ phải nạp tiền vào game để mua đồ. 
Quá trình nạp tiền này là trong lúc chơi game và khi khách hàng có nhu cầu mua đồ. </font></div>
				<div style="text-align: justify; ">
				<font size="2">Identification of subscription service:</font></div>	
				<div style="text-align: justify; ">
				<font size="2">Đồ có thể được mua qua sms hoặc nạp vào thông qua thẻ cào. 
SMS thì mỗi lần nạp tiền gồm các mệnh giá như sau :</font></div>	
				<div style="text-align: justify; ">
				<font size="2">
					<ul>
						<li>- Tin 6011:    500 đ</li>
						<li>- Tin 6111:    1.000 đ</li>
						<li>- Tin 6211:    2.000 đ</li>
						<li>- Tin 6311:    3.000 đ</li>
						<li>- Tin 6411:    4.000 đ</li>
						<li>- Tin 6511:    5.000 đ</li>
						<li>- Tin 6611:    10.000 đ</li>
						<li>- Tin 6711:    15.000 đ</li>
					</ul>
				</font></div>
				<div style="text-align: justify; ">
				<font size="2">Thẻ cào thì có rất nhiều mệnh giá, 10.000, 20.000, 30.000, 50.000, 100.000, 500.000 VND . Tùy vào mức độ khách hàng muốn nạp</font></div>
				<div style="text-align: justify; ">
				<font size="2">Pricing:</font></div>	
				<div style="text-align: justify; ">
				<font size="2">Khi nạp tiền vào game, tiền này sẽ được chuyển thành đơn vị tiền tệ trong game và khách hàng phải dùng tiền tệ ở trong game để mua đồ. 
Giá tiền cho từng độ vật sẽ rất khác nhau tùy thuộc vào đặc tính mà đồ vật đó mang lại. </font></div>
				<div style="text-align: justify; ">
				<font size="2">Liên hệ với chúng tôi:</font></div>
				<div style="text-align: justify; ">
				<font size="2">Công ty Cổ phần Giải pháp CNTT và Truyền thông SunNet</font></div>
				<div style="text-align: justify; ">
				<font size="2">Ðịa chỉ: Tầng 5, Toà nhà CTy CP May Nông Nghiệp, Số 1/120 Truờng Chinh - Ðống Ða - Hà Nội.</font></div>
				<div style="text-align: justify; ">
				<font size="2">Tel: +84-4 3576 6083 </font></div>
				<div style="text-align: justify; ">
				<font size="2">CSKH: +84-4 3576 6085 </font></div>
				<div style="text-align: justify; ">
				<font size="2">Fax: +84-4 3576 5504</font></div>
				<div style="text-align: justify; ">
				<font size="2">Email: contact@sunnet.vn</font></div>
			</span>
		</div>	
        <input type="hidden" name="sid" value="0" id="sid">	</div>
</div></body></html>