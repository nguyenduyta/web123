<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>menu da cap - menu da cap css, hoc css, tao menu da cap voi css</title>
<style>
a{
    text-decoration: none;
}
ul.drop{
 list-style:none;
 margin:0px;
 padding:0px;
 width:200px;
 border:1px solid #f1f1f1;
}
ul.drop li,ul.drop li a{ 
 border-bottom:1px solid #fbfbfb;
 height:32px;
 line-height:32px;
 padding-left:5px;
 position:relative;
    display: block;
    text-decoration: none;
    color: darkblue;
}
ul.drop li:hover,ul.drop li a:hover{
 display:block;
 background:#fbfbfb;
    color: red;
}
ul.drop li > ul.drop{
 position:absolute;
 top:0px; 
 left:200px;
 display:none;
}
ul.drop li:hover > ul.drop{
 display:block;
}
</style>
</head>
<body>
<h1>Đào tạo lập trình web - Lập trình PHP MYSQL - Đào tạo lập trình suntech - Phone  0973.980.948</h1>
<h3>
    <a href="http://web24h.com.vn/chi-tiet-khoa-hoc/1350-khoa-hoc-web-giao-dien---web-tinh.html.html" title="Khóa học web giao diện - Khóa học web layout - Khóa học web tĩnh">+ Khóa học web giao diện - Web tĩnh</a>
</h3>
<h3><a href="http://web24h.com.vn/chi-tiet-khoa-hoc//1351-khoa-hoc-php-can-ban.html.html" title="Khóa học PHP căn bản">+ Khóa học PHP căn bản</a></h3>
<h3><a href="http://web24h.com.vn/chi-tiet-khoa-hoc/1352-khoa-hoc-php-nang-cao.html.html" title="Khóa học PHP nâng cao">+ Khóa học PHP nâng cao</a></h3>
<h3><a href="http://web24h.com.vn/chi-tiet-khoa-hoc/1353-khoa-hoc-php-chuyen-sau---php-framework.html.html" title="Khóa học PHP chuyên sâu - PHP Framework">+ Khóa học PHP chuyên sâu - PHP Framework</a></h3>

<ul class="drop">
 <li><a href="#">Menu item 1</a>
    <ul class="drop">
                <li><a href="#">Menu item 3.1</a></li>
                <li><a href="#">Menu item 3.2</a></li>
                <li><a href="#">Menu item 3.3</a></li>
                <li><a href="#">Menu item 3.4</a>
                 <ul class="drop">
                                    <li><a href="#">Menu item 3.4.1</a></li>
                                    <li><a href="#">Menu item 3.4.2</a></li>
                                    <li><a href="#">Menu item 3.4.3</a></li>
                                    <li><a href="#">Menu item 3.4.4</a></li>
                                    <li><a href="#">Menu item 3.4.5</a>
                                           <ul class="drop">
                                                        <li><a href="#">Menu item 3.4.5.1</a></li>
                                                        <li><a href="#">Menu item 3.4.5.2</a></li>
                                                        <li><a href="#">Menu item 3.4.5.3</a></li>
                                                        <li><a href="#">Menu item 3.4.5.4</a>
                                                           <ul class="drop">
                                                                <li><a href="#">Menu item 3.4.5.1.1</a></li>
                                                                <li><a href="#">Menu item 3.4.5.1.2</a></li>
                                                                <li><a href="#">Menu item 3.4.5.1.3</a></li>
                                                                <li><a href="#">Menu item 3.4.5.1.4</a>
                                                                   <ul class="drop">
                                                                       <li><a href="#">Menu item 3.4.5.1.4.1</a></li>
                                                                       <li><a href="#">Menu item 3.4.5.1.4.2</a></li>
                                                                       <li><a href="#">Menu item 3.4.5.1.4.3</a></li>
                                                                       <li><a href="#">Menu item 3.4.5.1.4.4</a></li>
                                                                   </ul>
                                                            </li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                    </li>
                                </ul>  
                </li>
            </ul> 
 </li>
 <li><a href="#">Menu item 2</a>
    <ul class="drop">
                <li><a href="#">Menu item 3.1</a></li>
                <li><a href="#">Menu item 3.2</a></li>
                <li><a href="#">Menu item 3.3</a></li>
                <li><a href="#">Menu item 3.4</a>
                 <ul class="drop">
                                    <li><a href="#">Menu item 3.4.1</a></li>
                                    <li><a href="#">Menu item 3.4.2</a></li>
                                    <li><a href="#">Menu item 3.4.3</a></li>
                                    <li><a href="#">Menu item 3.4.4</a></li>
                                    <li><a href="#">Menu item 3.4.5</a>
                                           <ul class="drop">
                                                        <li><a href="#">Menu item 3.4.5.1</a></li>
                                                        <li><a href="#">Menu item 3.4.5.2</a></li>
                                                        <li><a href="#">Menu item 3.4.5.3</a></li>
                                                        <li><a href="#">Menu item 3.4.5.4</a>
                                                           <ul class="drop">
                                                                <li><a href="#">Menu item 3.4.5.1.1</a></li>
                                                                <li><a href="#">Menu item 3.4.5.1.2</a></li>
                                                                <li><a href="#">Menu item 3.4.5.1.3</a></li>
                                                                <li><a href="#">Menu item 3.4.5.1.4</a>
                                                                   <ul class="drop">
                                                                       <li><a href="#">Menu item 3.4.5.1.4.1</a></li>
                                                                       <li><a href="#">Menu item 3.4.5.1.4.2</a></li>
                                                                       <li><a href="#">Menu item 3.4.5.1.4.3</a></li>
                                                                       <li><a href="#">Menu item 3.4.5.1.4.4</a></li>
                                                                   </ul>
                                                            </li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                    </li>
                                </ul>  
                </li>
            </ul> 
 </li>
 <li><a href="#">Menu item 3</a>
      <ul class="drop">
                <li><a href="#">Menu item 3.1</a></li>
                <li><a href="#">Menu item 3.2</a></li>
                <li><a href="#">Menu item 3.3</a></li>
                <li><a href="#">Menu item 3.4</a>
                 <ul class="drop">
                                    <li><a href="#">Menu item 3.4.1</a></li>
                                    <li><a href="#">Menu item 3.4.2</a></li>
                                    <li><a href="#">Menu item 3.4.3</a></li>
                                    <li><a href="#">Menu item 3.4.4</a></li>
                                    <li><a href="#">Menu item 3.4.5</a>
                                           <ul class="drop">
                                                        <li><a href="#">Menu item 3.4.5.1</a></li>
                                                        <li><a href="#">Menu item 3.4.5.2</a></li>
                                                        <li><a href="#">Menu item 3.4.5.3</a></li>
                                                        <li><a href="#">Menu item 3.4.5.4</a>
                                                           <ul class="drop">
                                                                <li><a href="#">Menu item 3.4.5.1.1</a></li>
                                                                <li><a href="#">Menu item 3.4.5.1.2</a></li>
                                                                <li><a href="#">Menu item 3.4.5.1.3</a></li>
                                                                <li><a href="#">Menu item 3.4.5.1.4</a>
                                                                   <ul class="drop">
                                                                       <li><a href="#">Menu item 3.4.5.1.4.1</a></li>
                                                                       <li><a href="#">Menu item 3.4.5.1.4.2</a></li>
                                                                       <li><a href="#">Menu item 3.4.5.1.4.3</a></li>
                                                                       <li><a href="#">Menu item 3.4.5.1.4.4</a></li>
                                                                   </ul>
                                                            </li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                    </li>
                                </ul>  
                </li>
            </ul> 
    </li>
    <li><a href="#">Menu item 4</a></li>
    <li><a href="#">Menu item 5</a>
        <ul class="drop">
                <li><a href="#">Menu item 3.1</a></li>
                <li><a href="#">Menu item 3.2</a></li>
                <li><a href="#">Menu item 3.3</a></li>
                <li><a href="#">Menu item 3.4</a>
                 <ul class="drop">
                                    <li><a href="#">Menu item 3.4.1</a></li>
                                    <li><a href="#">Menu item 3.4.2</a></li>
                                    <li><a href="#">Menu item 3.4.3</a></li>
                                    <li><a href="#">Menu item 3.4.4</a></li>
                                    <li><a href="#">Menu item 3.4.5</a>
                                           <ul class="drop">
                                                        <li><a href="#">Menu item 3.4.5.1</a></li>
                                                        <li><a href="#">Menu item 3.4.5.2</a></li>
                                                        <li><a href="#">Menu item 3.4.5.3</a></li>
                                                        <li><a href="#">Menu item 3.4.5.4</a>
                                                           <ul class="drop">
                                                                <li><a href="#">Menu item 3.4.5.1.1</a></li>
                                                                <li><a href="#">Menu item 3.4.5.1.2</a></li>
                                                                <li><a href="#">Menu item 3.4.5.1.3</a></li>
                                                                <li><a href="#">Menu item 3.4.5.1.4</a>
                                                                   <ul class="drop">
                                                                       <li><a href="#">Menu item 3.4.5.1.4.1</a></li>
                                                                       <li><a href="#">Menu item 3.4.5.1.4.2</a></li>
                                                                       <li><a href="#">Menu item 3.4.5.1.4.3</a></li>
                                                                       <li><a href="#">Menu item 3.4.5.1.4.4</a></li>
                                                                   </ul>
                                                            </li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                    </li>
                                </ul>  
                </li>
            </ul> 
    </li>
    <li><a href="#">Menu item 6</a></li>
    <li><a href="#">Menu item 4</a></li>
    <li><a href="#">Menu item 8</a></li>
    <li><a href="#">Menu item 9</a>
        <ul class="drop">
                <li><a href="#">Menu item 3.1</a></li>
                <li><a href="#">Menu item 3.2</a></li>
                <li><a href="#">Menu item 3.3</a></li>
                <li><a href="#">Menu item 3.4</a>
                 <ul class="drop">
                                    <li><a href="#">Menu item 3.4.1</a></li>
                                    <li><a href="#">Menu item 3.4.2</a></li>
                                    <li><a href="#">Menu item 3.4.3</a></li>
                                    <li><a href="#">Menu item 3.4.4</a></li>
                                    <li><a href="#">Menu item 3.4.5</a>
                                           <ul class="drop">
                                                        <li><a href="#">Menu item 3.4.5.1</a></li>
                                                        <li><a href="#">Menu item 3.4.5.2</a></li>
                                                        <li><a href="#">Menu item 3.4.5.3</a></li>
                                                        <li><a href="#">Menu item 3.4.5.4</a>
                                                           <ul class="drop">
                                                                <li><a href="#">Menu item 3.4.5.1.1</a></li>
                                                                <li><a href="#">Menu item 3.4.5.1.2</a></li>
                                                                <li><a href="#">Menu item 3.4.5.1.3</a></li>
                                                                <li><a href="#">Menu item 3.4.5.1.4</a>
                                                                   <ul class="drop">
                                                                       <li><a href="#">Menu item 3.4.5.1.4.1</a></li>
                                                                       <li><a href="#">Menu item 3.4.5.1.4.2</a></li>
                                                                       <li><a href="#">Menu item 3.4.5.1.4.3</a></li>
                                                                       <li><a href="#">Menu item 3.4.5.1.4.4</a></li>
                                                                   </ul>
                                                            </li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                    </li>
                                </ul>  
                </li>
            </ul> 
    </li>
    <li><a href="#">Menu item 10</a></li>
</ul>
</body>
</html>