<!DOCTYPE HTML>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="HTKHOI" />
    <meta charset="utf-8" />
	<title>FIRST APP</title>
    <link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>/public/demo/sencha/resources/css/sencha-touch.css" />
    <script type="text/javascript" src="<?php echo base_url(); ?>/public/demo/sencha/resources/sencha-touch-all.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>/public/demo/sencha/demo1/home.js"></script>
</head>
<body>

</body>
</html>