<!DOCTYPE HTML>
<head>
    <title>Chuongs trinh sencha extjs dau tien</title>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="HTKHOI" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url("public/demo"); ?>/extjs/resources/css/ext-all.css" />
    <script type="text/javascript" src="<?php echo base_url("public/demo"); ?>/extjs/ext-all.js"></script>
    <script type="text/javascript" src="<?php echo base_url("public/demo"); ?>/extjs/app.js"></script>
</head>
<body>
</body>
</html>