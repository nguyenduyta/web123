<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//System Information
$config['config_background'] 	= '#FFFFFF';
$config['config_favicon'] 		= '';
$config['config_logo'] 			= 'http://web24h.com.vn/ajaxfilemanager/uploaded/logo5.png';
$config['config_banner'] 		= '';
$config['config_banner1'] 		= '';
$config['config_banner2'] 		= '';
$config['config_banner3'] 		= '';
$config['config_banner4'] 		= '';
$config['config_contact'] 		= '<strong>SUNTECH dạy gì ?</strong><br />
- Các khóa học ở <strong>SUNTECH </strong>đều là những khóa đào tạo về lập trình web nói chung và lập trình <strong>PHP MYSQL</strong> nói riêng<br />
&#160; -<strong> SUNTECH</strong> không có cơ sở vật chất tốt như những trung  tâm đào tạo lớn. Nhưng điều đó không có nghĩa là chất lượng học sẽ kém  hơn. SUNTECH&#160;tự tin là sẽ giúp các bạn theo học có một kiến thức chuẩn  nhất và vững chắc nhất để giúp các bạn có thể làm việc thực tế. <strong>SUNTECH </strong>  không giúp các bạn có&#160; bước đi nhanh nhất những sẽ giúp các bạn có  những bước tiến vững chắc nhất. Bởi tôi thấy hiện tại ở Hà Nội có một số  đơn vị quảng cáo các khóa <strong>học PHP&#160;MYSQL</strong> chỉ có 10 ngày  có những chỗ thì 2 tuần. Điều này là hoàn toàn không thể. Các bạn nghĩ  mình sẽ học được gì trong thời gian ngắn ngủi đó.<br />
&#160; - <strong>SUNTECH</strong> không thiên về chứng chỉ. Bởi lẽ một chứng  chỉ trong tay nhưng kiến thức trống rỗng thì các bạn vẫn thât nghiệp và  chứng chỉ đó trở nên vô nghĩa<br />
<strong>Ai là người sáng lập ra SUNTECH </strong>?<br />
&#160;&#160; <font size="2">Cũng trải qua những năm tháng sinh viên như các bạn, cũng bắt đầu vạch xuất phát là con số 0 rất tròn trĩnh<img border="0" class="inlineimg" title="lè lưỡi" alt="" src="http://www.vn-zoom.com/images/smilies/10.gif" />   và chưa bao giờ nghĩ tới việc mình sẽ theo lập trình chỉ vì một suy   nghĩ là "thấy người khác bảo nó khó"  nên Mình đã lãng phí mất một   khoảng thời gian rất dài cho những việc vô nghĩa. <br />
&#160; Nhưng hiện giờ thì Mình lại là một lập trình viên rồi một team  leader  cho một công ty thiết kế web rất lớn ở Hà Nội. Thật không thể tin  được  phải không các bạn.</font>&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160; <br />
&#160;&#160; - Chắc hẳn các bạn đã nghe nhiều đến cái tên htkhoi trong một số bài viết trên <a href="http://web24h.com.vn">web24h.com.vn</a>. <br />
&#160;&#160; - <strong>Vậy htkhoi là ai ?</strong><br />
&#160; &#160;&#160; &#160; FullName: Phạm Kỳ Khôi<br />
&#160;&#160;&#160;&#160;&#160;&#160; Phone:&#160;&#160;&#160;&#160;&#160; 0973.980.948<br />
&#160;&#160;&#160;&#160;&#160;&#160; Email:&#160;&#160;&#160;&#160;&#160;&#160; phamkykhoi.info@gmail.com<br />
&#160;&#160;&#160;&#160;&#160;&#160; Facebook: <a target="_blank" href="https://www.facebook.com/phamky.khoi">here</a><br />
&#160;&#160;&#160;&#160;&#160;&#160; Học trò của thầy Kenny Huy ( CEO and FOUNDER QHONLINE )<br />
<strong>&#160;&#160;&#160; - htkhoi&#160; làm gì ?</strong><br />
&#160;&#160;&#160;&#160;&#160;&#160; Hiện tôi đang là team leader cho bộ phận web của công ty sunnet. Rất mong được sự đóng góp của các bạn cho <strong>SUNTECH&#160;</strong>';
$config['config_footer'] 		= '&#160;&#160;&#160; Lịch khai giảng các khóa học của tháng 03 / 2014 &#160; tại SUNTECH<br />
&#160;&#160;&#160; Chương trình học các bạn có thể xem ở bảng bên dưới<br />
<br />
<table width="664" cellspacing="1px" cellpadding="5px" bgcolor="#e3e4e5">
    <tbody>
        <tr valign="middle">
            <td width="45%" nowrap="nowrap" bgcolor="#f1f1f1" align="left"><strong><span>LỊCH      KHAI GIẢNG</span></strong></td>
            <td width="11%" bgcolor="#f1f1f1" align="center"><b>Khai giảng</b></td>
            <td width="15%" bgcolor="#f1f1f1" align="center"><b>Lịch học</b></td>
            <td width="14%" bgcolor="#f1f1f1" align="center"><b>Giờ học</b></td>
            <td width="10%" bgcolor="#f1f1f1" align="center"><b>Địa điểm</b></td>
        </tr>
        <tr valign="middle">
            <td nowrap="nowrap" bgcolor="#ffffff" align="left"><a href="http://web24h.com.vn/chi-tiet-khoa-hoc/1350-khoa-hoc-web-giao-dien---web-tinh.html.html" target="_parent">        <b>Khóa học web giao diện - web tĩnh</b></a></td>
            <td bgcolor="#ffffff" align="center">10/04/2014</td>
            <td bgcolor="#ffffff" align="center">2-4-6</td>
            <td bgcolor="#ffffff" align="center">19h00       -       21h00</td>
            <td bgcolor="#ffffff" align="center">Hà Nội</td>
        </tr>
        <tr valign="middle">
            <td nowrap="nowrap" bgcolor="#ffffff" align="left"><a href="http://web24h.com.vn/chi-tiet-khoa-hoc//1351-khoa-hoc-php-can-ban.html.html" target="_parent">        <b>Khóa học PHP căn bản</b>       </a></td>
            <td bgcolor="#ffffff" align="center">10/04/2014</td>
            <td bgcolor="#ffffff" align="center">3-5-7</td>
            <td bgcolor="#ffffff" align="center">9h00       - 11h30</td>
            <td bgcolor="#ffffff" align="center">Hà Nội</td>
        </tr>
        <tr valign="middle">
            <td nowrap="nowrap" bgcolor="#ffffff" align="left"><a href="http://web24h.com.vn/chi-tiet-khoa-hoc/1352-khoa-hoc-php-nang-cao.html.html" target="_parent">        <b>Khóa học PHP nâng cao</b>       </a></td>
            <td bgcolor="#ffffff" align="center">15/04/2014</td>
            <td bgcolor="#ffffff" align="center">2-4-6</td>
            <td bgcolor="#ffffff" align="center">14h00       - 16h30</td>
            <td bgcolor="#ffffff" align="center">Hà Nội</td>
        </tr>
        <tr valign="middle">
            <td nowrap="nowrap" bgcolor="#ffffff" align="left"><a href="http://web24h.com.vn/chi-tiet-khoa-hoc/1353-khoa-hoc-php-chuyen-sau---php-framework.html.html"><strong>Khóa học PHP chuyên sâu - PHP Framework</strong></a></td>
            <td bgcolor="#ffffff" align="center">15/04/2014</td>
            <td bgcolor="#ffffff" align="center">3-5-7</td>
            <td bgcolor="#ffffff" align="center">7h00 - 9h00</td>
            <td bgcolor="#ffffff" align="center">Hà Nội</td>
        </tr>
    </tbody>
</table>
<br />
<strong><span>Thông tin liên hệ<br />
&#160;&#160;&#160;&#160;&#160; </span></strong>Name: Ban quản trị<br />
&#160;&#160;&#160;&#160;&#160; Email: daotaolaptrinhsuntech@gmail.com<br />
&#160;&#160;&#160;&#160;&#160; Phone: 0973.980.948<br />
&#160;&#160;&#160;&#160;&#160; website: <a href="http://web24h.com.vn">web24h.com.vn</a><br />
<br />';
$config['config_notice'] 		= '<br />';
$config['config_website_name'] 	= '';
$config['config_website_subject']= 'Học PHP ở hà nội - Học lập trình PHP - Học thiết kế web';
$config['config_desciption'] 	= 'Học lập trình web - Lập trình PHP từ căn bản đến nâng cao uy tín và chất lượng nhất Hà Nội. Sau khóa học có thể xây dựng mọi ứng dụng web hoàn chỉnh sử dụng PHP, thiết kế và xây dựng được bất kỳ website nào.';
$config['config_keywords'] 		= 'Hoc Lap Trinh web, Hoc PHP o Ha Noi, Hoc PHP can ban, Hoc PHP nang cao, PHP Can Ban, PHP Nang Cao, Hoc Html Css, Lap Trinh PHP, Hoc PHP O Dau, PHP Va MYSQL, Hoc PHP Online, Tu hoc PHP, PHP Framework, Hoc php mysql, PHP MYSQL, Hoc thiet ke web';
$config['title_page'] 			= 'Học thiết kế web - Học lập trình php - Học php online';
$config['meta_desc'] 			= 'Học thiết kế web, học lập trình php uy tín chất lượng nhất hà nội. Kiến thức được học từ html-css, javascript-jquery, php căn bản và nâng cao, php framework';
$config['meta_keyword'] 			= 'Học thiết kế web, học lập trình php, học php online, học php ở hà nội, học thiết kế web ở hà nội';
$config['config_address'] 		= '';
$config['config_website'] 		= '';
$config['config_province'] 		= '';
$config['config_district'] 		= '';
$config['config_email'] 			= '';
$config['config_skype'] 			= '';
$config['config_yahoo'] 			= '';
$config['config_facebook'] 		= '';
$config['config_phone'] 			= '';
$config['config_mobile'] 		= '';
$config['config_fax'] 			= '';
//Config System
$config['config_maintain'] = '0';
